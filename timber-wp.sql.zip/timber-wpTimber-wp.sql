-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 28, 2022 at 09:56 PM
-- Server version: 8.0.24
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `timber-wp`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint UNSIGNED NOT NULL,
  `comment_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE `wp_comments` (
  `comment_ID` bigint UNSIGNED NOT NULL,
  `comment_post_ID` bigint UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Комментатор WordPress', 'wapuu@wordpress.example', 'https://ru.wordpress.org/', '', '2022-09-27 00:04:38', '2022-09-26 21:04:38', 'Привет! Это комментарий.\nЧтобы начать модерировать, редактировать и удалять комментарии, перейдите на экран «Комментарии» в консоли.\nАватары авторов комментариев загружаются с сервиса <a href=\"https://ru.gravatar.com/\">Gravatar</a>.', 0, '1', '', 'comment', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE `wp_links` (
  `link_id` bigint UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE `wp_options` (
  `option_id` bigint UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://timber-house', 'yes'),
(2, 'home', 'http://timber-house', 'yes'),
(3, 'blogname', 'Timber House', 'yes'),
(4, 'blogdescription', 'Timber House - Best houses construction team', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'mark23y_special@ukr.net', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'd.m.Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'd.m.Y H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '', 'yes'),
(29, 'rewrite_rules', '', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:2:{i:0;s:30:\"advanced-custom-fields/acf.php\";i:1;s:45:\"wf-magnific-lightbox/wf-magnific-lightbox.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '3', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:2:{i:0;s:84:\"D:\\OpenServer\\domains\\timber-house/wp-content/plugins/advanced-custom-fields/acf.php\";i:1;s:0:\"\";}', 'no'),
(40, 'template', 'timber', 'yes'),
(41, 'stylesheet', 'timber', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '53496', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '2', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '7', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1679778277', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '53496', 'yes'),
(100, 'wp_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(101, 'fresh_site', '0', 'yes'),
(102, 'WPLANG', 'ru_RU', 'yes'),
(103, 'user_count', '1', 'no'),
(104, 'widget_block', 'a:6:{i:2;a:1:{s:7:\"content\";s:19:\"<!-- wp:search /-->\";}i:3;a:1:{s:7:\"content\";s:167:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Свежие записи</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->\";}i:4;a:1:{s:7:\"content\";s:247:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Свежие комментарии</h2><!-- /wp:heading --><!-- wp:latest-comments {\"displayAvatar\":false,\"displayDate\":false,\"displayExcerpt\":false} /--></div><!-- /wp:group -->\";}i:5;a:1:{s:7:\"content\";s:150:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Архивы</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->\";}i:6;a:1:{s:7:\"content\";s:154:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Рубрики</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'sidebars_widgets', 'a:2:{s:19:\"wp_inactive_widgets\";a:5:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";i:3;s:7:\"block-5\";i:4;s:7:\"block-6\";}s:13:\"array_version\";i:3;}', 'yes'),
(106, 'cron', 'a:7:{i:1666983890;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1666991089;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1666991090;a:4:{s:18:\"wp_https_detection\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1666991103;a:3:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:21:\"wp_update_user_counts\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1666991104;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1667336689;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}s:7:\"version\";i:2;}', 'yes'),
(107, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_archives', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(112, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(113, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(114, 'widget_meta', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(115, 'widget_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(116, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(117, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(118, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(120, 'recovery_keys', 'a:0:{}', 'yes'),
(123, 'theme_mods_twentytwentytwo', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1664227765;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:9:\"sidebar-2\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}}}}', 'yes'),
(126, 'https_detection_errors', 'a:1:{s:23:\"ssl_verification_failed\";a:1:{i:0;s:38:\"Проверка SSL неудачна.\";}}', 'yes'),
(145, 'can_compress_scripts', '0', 'no'),
(158, 'finished_updating_comment_type', '1', 'yes'),
(163, 'current_theme', 'Timber', 'yes'),
(164, 'theme_mods_timber', 'a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;}', 'yes'),
(165, 'theme_switched', '', 'yes'),
(185, '_transient_health-check-site-status-result', '{\"good\":13,\"recommended\":5,\"critical\":1}', 'yes'),
(207, 'widget_recent-posts', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(208, 'widget_recent-comments', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(223, '_site_transient_update_themes', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1666982741;s:7:\"checked\";a:4:{s:6:\"timber\";s:3:\"1.1\";s:12:\"twentytwenty\";s:3:\"2.0\";s:15:\"twentytwentyone\";s:3:\"1.6\";s:15:\"twentytwentytwo\";s:3:\"1.2\";}s:8:\"response\";a:0:{}s:9:\"no_update\";a:3:{s:12:\"twentytwenty\";a:6:{s:5:\"theme\";s:12:\"twentytwenty\";s:11:\"new_version\";s:3:\"2.0\";s:3:\"url\";s:42:\"https://wordpress.org/themes/twentytwenty/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/theme/twentytwenty.2.0.zip\";s:8:\"requires\";s:3:\"4.7\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:15:\"twentytwentyone\";a:6:{s:5:\"theme\";s:15:\"twentytwentyone\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentytwentyone/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentytwentyone.1.6.zip\";s:8:\"requires\";s:3:\"5.3\";s:12:\"requires_php\";s:3:\"5.6\";}s:15:\"twentytwentytwo\";a:6:{s:5:\"theme\";s:15:\"twentytwentytwo\";s:11:\"new_version\";s:3:\"1.2\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentytwentytwo/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentytwentytwo.1.2.zip\";s:8:\"requires\";s:3:\"5.9\";s:12:\"requires_php\";s:3:\"5.6\";}}s:12:\"translations\";a:0:{}}', 'no'),
(227, 'recently_activated', 'a:0:{}', 'yes'),
(228, 'acf_version', '6.0.0', 'yes'),
(298, 'wf-magnific-lightbox-copyright', 'a:1:{s:2:\"ru\";a:1:{s:15:\"copyrightPrefix\";s:0:\"\";}}', 'yes'),
(299, 'wf-magnific-lightbox-gallery', 'a:2:{s:19:\"presetMediaFilelink\";b:1;s:18:\"forceMediaFilelink\";b:1;}', 'yes'),
(345, 'category_children', 'a:0:{}', 'yes'),
(374, 'wp_calendar_block_has_published_posts', '1', 'yes'),
(443, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-6.0.3.zip\";s:6:\"locale\";s:5:\"ru_RU\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-6.0.3.zip\";s:10:\"no_content\";s:0:\"\";s:11:\"new_bundled\";s:0:\"\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:5:\"6.0.3\";s:7:\"version\";s:5:\"6.0.3\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.9\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1666982739;s:15:\"version_checked\";s:5:\"6.0.3\";s:12:\"translations\";a:0:{}}', 'no'),
(445, 'auto_core_update_notified', 'a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:23:\"mark23y_special@ukr.net\";s:7:\"version\";s:5:\"6.0.3\";s:9:\"timestamp\";i:1666904772;}', 'no'),
(530, '_transient_timeout_global_styles_timber', '1666982798', 'no'),
(531, '_transient_global_styles_timber', 'body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--duotone--dark-grayscale: url(\'#wp-duotone-dark-grayscale\');--wp--preset--duotone--grayscale: url(\'#wp-duotone-grayscale\');--wp--preset--duotone--purple-yellow: url(\'#wp-duotone-purple-yellow\');--wp--preset--duotone--blue-red: url(\'#wp-duotone-blue-red\');--wp--preset--duotone--midnight: url(\'#wp-duotone-midnight\');--wp--preset--duotone--magenta-yellow: url(\'#wp-duotone-magenta-yellow\');--wp--preset--duotone--purple-green: url(\'#wp-duotone-purple-green\');--wp--preset--duotone--blue-orange: url(\'#wp-duotone-blue-orange\');--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}', 'no'),
(533, '_site_transient_timeout_theme_roots', '1666984541', 'no'),
(534, '_site_transient_theme_roots', 'a:4:{s:6:\"timber\";s:7:\"/themes\";s:12:\"twentytwenty\";s:7:\"/themes\";s:15:\"twentytwentyone\";s:7:\"/themes\";s:15:\"twentytwentytwo\";s:7:\"/themes\";}', 'no'),
(535, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1666982742;s:8:\"response\";a:2:{s:30:\"advanced-custom-fields/acf.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:36:\"w.org/plugins/advanced-custom-fields\";s:4:\"slug\";s:22:\"advanced-custom-fields\";s:6:\"plugin\";s:30:\"advanced-custom-fields/acf.php\";s:11:\"new_version\";s:5:\"6.0.3\";s:3:\"url\";s:53:\"https://wordpress.org/plugins/advanced-custom-fields/\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/plugin/advanced-custom-fields.6.0.3.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png?rev=1082746\";s:2:\"1x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-128x128.png?rev=1082746\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";s:2:\"1x\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.7\";s:6:\"tested\";s:5:\"6.0.3\";s:12:\"requires_php\";s:3:\"5.6\";}s:19:\"akismet/akismet.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"5.0.1\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.5.0.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.0\";s:6:\"tested\";s:5:\"6.0.3\";s:12:\"requires_php\";s:3:\"5.2\";}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:2:{s:31:\"all-meta-tags/all-meta-tags.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:27:\"w.org/plugins/all-meta-tags\";s:4:\"slug\";s:13:\"all-meta-tags\";s:6:\"plugin\";s:31:\"all-meta-tags/all-meta-tags.php\";s:11:\"new_version\";s:4:\"4.47\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/all-meta-tags/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/all-meta-tags.4.47.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/all-meta-tags/assets/icon-256x256.png?rev=1472588\";s:2:\"1x\";s:66:\"https://ps.w.org/all-meta-tags/assets/icon-128x128.png?rev=1472588\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/all-meta-tags/assets/banner-1544x500.png?rev=1908659\";s:2:\"1x\";s:68:\"https://ps.w.org/all-meta-tags/assets/banner-772x250.png?rev=1908477\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.9\";}s:45:\"wf-magnific-lightbox/wf-magnific-lightbox.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:34:\"w.org/plugins/wf-magnific-lightbox\";s:4:\"slug\";s:20:\"wf-magnific-lightbox\";s:6:\"plugin\";s:45:\"wf-magnific-lightbox/wf-magnific-lightbox.php\";s:11:\"new_version\";s:6:\"0.9.13\";s:3:\"url\";s:51:\"https://wordpress.org/plugins/wf-magnific-lightbox/\";s:7:\"package\";s:70:\"https://downloads.wordpress.org/plugin/wf-magnific-lightbox.0.9.13.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/wf-magnific-lightbox/assets/icon-256x256.png?rev=1334275\";s:2:\"1x\";s:73:\"https://ps.w.org/wf-magnific-lightbox/assets/icon-128x128.png?rev=1334275\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:75:\"https://ps.w.org/wf-magnific-lightbox/assets/banner-772x250.png?rev=1334275\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:5:\"3.0.1\";}}s:7:\"checked\";a:4:{s:30:\"advanced-custom-fields/acf.php\";s:5:\"6.0.0\";s:19:\"akismet/akismet.php\";s:3:\"5.0\";s:31:\"all-meta-tags/all-meta-tags.php\";s:4:\"4.47\";s:45:\"wf-magnific-lightbox/wf-magnific-lightbox.php\";s:6:\"0.9.13\";}}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint UNSIGNED NOT NULL,
  `post_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_edit_lock', '1664319230:1'),
(4, 6, '_wp_attached_file', '2022/09/pngwing.com-15.png'),
(5, 6, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:512;s:6:\"height\";i:512;s:4:\"file\";s:26:\"2022/09/pngwing.com-15.png\";s:8:\"filesize\";i:125489;s:5:\"sizes\";a:2:{s:6:\"medium\";a:5:{s:4:\"file\";s:26:\"pngwing.com-15-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:58409;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:26:\"pngwing.com-15-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:22129;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(6, 6, '_wp_attachment_image_alt', 'Logo'),
(7, 7, '_wp_attached_file', '2022/09/cropped-pngwing.com-15.png'),
(8, 7, '_wp_attachment_context', 'site-icon'),
(9, 7, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:512;s:6:\"height\";i:512;s:4:\"file\";s:34:\"2022/09/cropped-pngwing.com-15.png\";s:8:\"filesize\";i:120674;s:5:\"sizes\";a:6:{s:6:\"medium\";a:5:{s:4:\"file\";s:34:\"cropped-pngwing.com-15-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:58409;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:34:\"cropped-pngwing.com-15-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:22129;}s:13:\"site_icon-270\";a:5:{s:4:\"file\";s:34:\"cropped-pngwing.com-15-270x270.png\";s:5:\"width\";i:270;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:49826;}s:13:\"site_icon-192\";a:5:{s:4:\"file\";s:34:\"cropped-pngwing.com-15-192x192.png\";s:5:\"width\";i:192;s:6:\"height\";i:192;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:31044;}s:13:\"site_icon-180\";a:5:{s:4:\"file\";s:34:\"cropped-pngwing.com-15-180x180.png\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:28156;}s:12:\"site_icon-32\";a:5:{s:4:\"file\";s:32:\"cropped-pngwing.com-15-32x32.png\";s:5:\"width\";i:32;s:6:\"height\";i:32;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:2518;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(10, 5, '_wp_trash_meta_status', 'publish'),
(11, 5, '_wp_trash_meta_time', '1664319251'),
(12, 3, '_wp_trash_meta_status', 'draft'),
(13, 3, '_wp_trash_meta_time', '1664320078'),
(14, 3, '_wp_desired_post_slug', 'privacy-policy'),
(15, 2, '_edit_lock', '1664491266:1'),
(16, 2, '_edit_last', '1'),
(17, 12, '_edit_last', '1'),
(18, 12, '_edit_lock', '1664487425:1'),
(19, 2, 'header__name', 'Timber House'),
(20, 2, '_header__name', 'field_63343c9b724e5'),
(21, 2, 'phone', '+380 (98) 298-24-08'),
(22, 2, '_phone', 'field_63343d284e2ad'),
(23, 2, 'header__title', 'Дома из бруса под ключ'),
(24, 2, '_header__title', 'field_63343dc64716a'),
(25, 23, 'header__name', 'Super Timber'),
(26, 23, '_header__name', 'field_63343c9b724e5'),
(27, 23, 'phone', '+380 (98) 298-24-08'),
(28, 23, '_phone', 'field_63343d284e2ad'),
(29, 23, 'header__title', 'Новые дома из бруса быстро'),
(30, 23, '_header__title', 'field_63343dc64716a'),
(31, 26, '_wp_attached_file', '2022/09/slider-header3.jpg'),
(32, 26, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1920;s:6:\"height\";i:1077;s:4:\"file\";s:26:\"2022/09/slider-header3.jpg\";s:8:\"filesize\";i:1506933;s:5:\"sizes\";a:5:{s:6:\"medium\";a:5:{s:4:\"file\";s:26:\"slider-header3-300x168.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:168;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:42941;}s:5:\"large\";a:5:{s:4:\"file\";s:27:\"slider-header3-1024x574.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:574;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:292301;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:26:\"slider-header3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:30259;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:26:\"slider-header3-768x431.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:431;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:167395;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:27:\"slider-header3-1536x862.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:862;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:638743;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1663675929\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(33, 26, '_wp_attachment_image_alt', 'Фоновое изображение'),
(34, 2, 'top__bg', '26'),
(35, 2, '_top__bg', 'field_633444385ce53'),
(36, 2, 'header__sale', '28'),
(37, 2, '_header__sale', 'field_6334436dd3b0f'),
(38, 27, 'header__name', 'Timber House'),
(39, 27, '_header__name', 'field_63343c9b724e5'),
(40, 27, 'phone', '+380 (98) 298-24-08'),
(41, 27, '_phone', 'field_63343d284e2ad'),
(42, 27, 'header__title', 'Дома из бруса под ключ'),
(43, 27, '_header__title', 'field_63343dc64716a'),
(44, 27, 'top__bg', '26'),
(45, 27, '_top__bg', 'field_633444385ce53'),
(46, 27, 'header__sale', ''),
(47, 27, '_header__sale', 'field_6334436dd3b0f'),
(48, 28, '_wp_attached_file', '2022/09/sale.png'),
(49, 28, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:252;s:6:\"height\";i:251;s:4:\"file\";s:16:\"2022/09/sale.png\";s:8:\"filesize\";i:79428;s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:5:{s:4:\"file\";s:16:\"sale-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:26881;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(50, 28, '_wp_attachment_image_alt', 'Подарок'),
(51, 29, 'header__name', 'Timber House'),
(52, 29, '_header__name', 'field_63343c9b724e5'),
(53, 29, 'phone', '+380 (98) 298-24-08'),
(54, 29, '_phone', 'field_63343d284e2ad'),
(55, 29, 'header__title', 'Дома из бруса под ключ'),
(56, 29, '_header__title', 'field_63343dc64716a'),
(57, 29, 'top__bg', '26'),
(58, 29, '_top__bg', 'field_633444385ce53'),
(59, 29, 'header__sale', '28'),
(60, 29, '_header__sale', 'field_6334436dd3b0f'),
(61, 30, 'header__name', 'Timber House'),
(62, 30, '_header__name', 'field_63343c9b724e5'),
(63, 30, 'phone', '+380 (98) 298-24-08'),
(64, 30, '_phone', 'field_63343d284e2ad'),
(65, 30, 'header__title', 'Дома из бруса под ключ'),
(66, 30, '_header__title', 'field_63343dc64716a'),
(67, 30, 'top__bg', '26'),
(68, 30, '_top__bg', 'field_633444385ce53'),
(69, 30, 'header__sale', '28'),
(70, 30, '_header__sale', 'field_6334436dd3b0f'),
(71, 2, 'main__title', 'Строительство домов и бань из строганного и профилированного бруса'),
(72, 2, '_main__title', 'field_63344920b500c'),
(73, 2, 'main__text', '<div>\r\n<div>За <strong>10 лет</strong> мы возвели больше <strong>250 домов</strong> и бань из бруса.</div>\r\n&nbsp;\r\n<div>Имеем большой опыт в строительстве.</div>\r\n<div><em>Гарантируем качество и надежность всех построенных нами объектов.</em></div>\r\n&nbsp;\r\n<div><strong>ГАРАНТИЯ НА ДОМА И БАНИ ИЗ БРУСА 3 ГОДА!</strong></div>\r\n</div>\r\n&nbsp;'),
(74, 2, '_main__text', 'field_633449a8b500d'),
(75, 33, 'header__name', 'Timber House'),
(76, 33, '_header__name', 'field_63343c9b724e5'),
(77, 33, 'phone', '+380 (98) 298-24-08'),
(78, 33, '_phone', 'field_63343d284e2ad'),
(79, 33, 'header__title', 'Дома из бруса под ключ'),
(80, 33, '_header__title', 'field_63343dc64716a'),
(81, 33, 'top__bg', '26'),
(82, 33, '_top__bg', 'field_633444385ce53'),
(83, 33, 'header__sale', '28'),
(84, 33, '_header__sale', 'field_6334436dd3b0f'),
(85, 33, 'main__title', 'Строительство домов и бань из строганного и профилированного бруса'),
(86, 33, '_main__title', 'field_63344920b500c'),
(87, 33, 'main__text', '<div>\r\n<div>За 10 лет мы возвели больше 250 домов и бань из бруса. Имеем большой опыт в строительстве. Гарантируем качество и надежность всех построенных нами объектов. Гарантия на дома и бани из бруса 3 года!</div>\r\n</div>'),
(88, 33, '_main__text', 'field_633449a8b500d'),
(89, 35, 'header__name', 'Timber House'),
(90, 35, '_header__name', 'field_63343c9b724e5'),
(91, 35, 'phone', '+380 (98) 298-24-08'),
(92, 35, '_phone', 'field_63343d284e2ad'),
(93, 35, 'header__title', 'Дома из бруса под ключ'),
(94, 35, '_header__title', 'field_63343dc64716a'),
(95, 35, 'top__bg', '26'),
(96, 35, '_top__bg', 'field_633444385ce53'),
(97, 35, 'header__sale', '28'),
(98, 35, '_header__sale', 'field_6334436dd3b0f'),
(99, 35, 'main__title', 'Строительство домов и бань из строганного и профилированного бруса'),
(100, 35, '_main__title', 'field_63344920b500c'),
(101, 35, 'main__text', '<div>\r\n<div>За 10 лет мы возвели больше 250 домов и бань из бруса. Имеем большой опыт в строительстве. Гарантируем качество и надежность всех построенных нами объектов. Гарантия на дома и бани из бруса 3 года!</div>\r\n</div>'),
(102, 35, '_main__text', 'field_633449a8b500d'),
(103, 36, 'header__name', 'Timber House'),
(104, 36, '_header__name', 'field_63343c9b724e5'),
(105, 36, 'phone', '+380 (98) 298-24-08'),
(106, 36, '_phone', 'field_63343d284e2ad'),
(107, 36, 'header__title', 'Дома из бруса под ключ'),
(108, 36, '_header__title', 'field_63343dc64716a'),
(109, 36, 'top__bg', '26'),
(110, 36, '_top__bg', 'field_633444385ce53'),
(111, 36, 'header__sale', '28'),
(112, 36, '_header__sale', 'field_6334436dd3b0f'),
(113, 36, 'main__title', 'Строительство домов и бань из строганного и профилированного бруса'),
(114, 36, '_main__title', 'field_63344920b500c'),
(115, 36, 'main__text', '<div>\r\n<div>За <strong>10 лет</strong> мы возвели больше <strong>250 домов</strong> и бань из бруса.</div>\r\n<div></div>\r\n<div>Имеем большой опыт в строительстве.</div>\r\n<div><em>Гарантируем качество и надежность всех построенных нами объектов. </em></div>\r\n<div></div>\r\n<div><strong>Гарантия на дома и бани из бруса 3 года!</strong></div>\r\n</div>\r\n&nbsp;'),
(116, 36, '_main__text', 'field_633449a8b500d'),
(117, 37, 'header__name', 'Timber House'),
(118, 37, '_header__name', 'field_63343c9b724e5'),
(119, 37, 'phone', '+380 (98) 298-24-08'),
(120, 37, '_phone', 'field_63343d284e2ad'),
(121, 37, 'header__title', 'Дома из бруса под ключ'),
(122, 37, '_header__title', 'field_63343dc64716a'),
(123, 37, 'top__bg', '26'),
(124, 37, '_top__bg', 'field_633444385ce53'),
(125, 37, 'header__sale', '28'),
(126, 37, '_header__sale', 'field_6334436dd3b0f'),
(127, 37, 'main__title', 'Строительство домов и бань из строганного и профилированного бруса'),
(128, 37, '_main__title', 'field_63344920b500c'),
(129, 37, 'main__text', '<div>\r\n<div>За <strong>10 лет</strong> мы возвели больше <strong>250 домов</strong> и бань из бруса.</div>\r\n&nbsp;\r\n<div>Имеем большой опыт в строительстве.</div>\r\n<div><em>Гарантируем качество и надежность всех построенных нами объектов.</em></div>\r\n&nbsp;\r\n<div><strong>Гарантия на дома и бани из бруса 3 года!</strong></div>\r\n</div>\r\n&nbsp;'),
(130, 37, '_main__text', 'field_633449a8b500d'),
(131, 38, 'header__name', 'Timber House'),
(132, 38, '_header__name', 'field_63343c9b724e5'),
(133, 38, 'phone', '+380 (98) 298-24-08'),
(134, 38, '_phone', 'field_63343d284e2ad'),
(135, 38, 'header__title', 'Дома из бруса под ключ'),
(136, 38, '_header__title', 'field_63343dc64716a'),
(137, 38, 'top__bg', '26'),
(138, 38, '_top__bg', 'field_633444385ce53'),
(139, 38, 'header__sale', '28'),
(140, 38, '_header__sale', 'field_6334436dd3b0f'),
(141, 38, 'main__title', 'Строительство домов и бань из строганного и профилированного бруса'),
(142, 38, '_main__title', 'field_63344920b500c'),
(143, 38, 'main__text', '<div>\r\n<div>За <strong>10 лет</strong> мы возвели больше <strong>250 домов</strong> и бань из бруса.</div>\r\n&nbsp;\r\n<div>Имеем большой опыт в строительстве.</div>\r\n<div><em>Гарантируем качество и надежность всех построенных нами объектов.</em></div>\r\n&nbsp;\r\n<div><strong>ГАРАНТИЯ НА ДОМА И БАНИ ИЗ БРУСА 3 ГОДА!</strong></div>\r\n</div>\r\n&nbsp;'),
(144, 38, '_main__text', 'field_633449a8b500d'),
(145, 40, '_wp_attached_file', '2022/09/item-1.jpg'),
(146, 40, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:250;s:6:\"height\";i:241;s:4:\"file\";s:18:\"2022/09/item-1.jpg\";s:8:\"filesize\";i:44892;s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:5:{s:4:\"file\";s:18:\"item-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:27266;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1664001720\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(147, 41, '_wp_attached_file', '2022/09/item-2.jpg'),
(148, 41, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:250;s:6:\"height\";i:241;s:4:\"file\";s:18:\"2022/09/item-2.jpg\";s:8:\"filesize\";i:44471;s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:5:{s:4:\"file\";s:18:\"item-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:26686;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1664001869\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(149, 42, '_wp_attached_file', '2022/09/item-3.jpg'),
(150, 42, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:250;s:6:\"height\";i:241;s:4:\"file\";s:18:\"2022/09/item-3.jpg\";s:8:\"filesize\";i:43477;s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:5:{s:4:\"file\";s:18:\"item-3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:25867;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1664001996\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(151, 43, '_wp_attached_file', '2022/09/item-4.jpg'),
(152, 43, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:250;s:6:\"height\";i:241;s:4:\"file\";s:18:\"2022/09/item-4.jpg\";s:8:\"filesize\";i:49939;s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:5:{s:4:\"file\";s:18:\"item-4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:29887;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1664002091\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(153, 44, '_wp_attached_file', '2022/09/item-5.jpg'),
(154, 44, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:240;s:6:\"height\";i:231;s:4:\"file\";s:18:\"2022/09/item-5.jpg\";s:8:\"filesize\";i:45060;s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:5:{s:4:\"file\";s:18:\"item-5-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:28314;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1664002595\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(155, 45, '_wp_attached_file', '2022/09/item-6.jpg'),
(156, 45, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:240;s:6:\"height\";i:231;s:4:\"file\";s:18:\"2022/09/item-6.jpg\";s:8:\"filesize\";i:54967;s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:5:{s:4:\"file\";s:18:\"item-6-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:34349;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1664002807\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(157, 46, '_wp_attached_file', '2022/09/item-7.jpg'),
(158, 46, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:240;s:6:\"height\";i:231;s:4:\"file\";s:18:\"2022/09/item-7.jpg\";s:8:\"filesize\";i:41979;s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:5:{s:4:\"file\";s:18:\"item-7-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:26321;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1664002935\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(159, 47, '_wp_attached_file', '2022/09/item-8.jpg'),
(160, 47, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:240;s:6:\"height\";i:231;s:4:\"file\";s:18:\"2022/09/item-8.jpg\";s:8:\"filesize\";i:45106;s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:5:{s:4:\"file\";s:18:\"item-8-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:28271;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1664003073\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(161, 47, '_wp_attachment_image_alt', 'Проект дома 1'),
(162, 46, '_wp_attachment_image_alt', 'Проект дома 2'),
(163, 45, '_wp_attachment_image_alt', 'Проект дома 3'),
(164, 44, '_wp_attachment_image_alt', 'Проект дома 4'),
(165, 43, '_wp_attachment_image_alt', 'Проект дома 5'),
(166, 42, '_wp_attachment_image_alt', 'Проект дома 6'),
(167, 41, '_wp_attachment_image_alt', 'Проект дома 7'),
(168, 40, '_wp_attachment_image_alt', 'Проект дома 8'),
(169, 2, 'gallery__inner', '[gallery size=\"full\" columns=\"4\" ids=\"40,42,43,44,45,46,47,41\" link=\"file\"]'),
(170, 2, '_gallery__inner', 'field_6334537d87fd8'),
(171, 48, 'header__name', 'Timber House'),
(172, 48, '_header__name', 'field_63343c9b724e5'),
(173, 48, 'phone', '+380 (98) 298-24-08'),
(174, 48, '_phone', 'field_63343d284e2ad'),
(175, 48, 'header__title', 'Дома из бруса под ключ'),
(176, 48, '_header__title', 'field_63343dc64716a'),
(177, 48, 'top__bg', '26'),
(178, 48, '_top__bg', 'field_633444385ce53'),
(179, 48, 'header__sale', '28'),
(180, 48, '_header__sale', 'field_6334436dd3b0f'),
(181, 48, 'main__title', 'Строительство домов и бань из строганного и профилированного бруса'),
(182, 48, '_main__title', 'field_63344920b500c'),
(183, 48, 'main__text', '<div>\r\n<div>За <strong>10 лет</strong> мы возвели больше <strong>250 домов</strong> и бань из бруса.</div>\r\n&nbsp;\r\n<div>Имеем большой опыт в строительстве.</div>\r\n<div><em>Гарантируем качество и надежность всех построенных нами объектов.</em></div>\r\n&nbsp;\r\n<div><strong>ГАРАНТИЯ НА ДОМА И БАНИ ИЗ БРУСА 3 ГОДА!</strong></div>\r\n</div>\r\n&nbsp;'),
(184, 48, '_main__text', 'field_633449a8b500d'),
(185, 48, 'gallery__inner', '[gallery size=\"full\" columns=\"4\" ids=\"40,42,43,44,45,46,47,41\" link=\"file\"]\r\n\r\nВаши фото'),
(186, 48, '_gallery__inner', 'field_6334537d87fd8'),
(187, 49, 'header__name', 'Timber House'),
(188, 49, '_header__name', 'field_63343c9b724e5'),
(189, 49, 'phone', '+380 (98) 298-24-08'),
(190, 49, '_phone', 'field_63343d284e2ad'),
(191, 49, 'header__title', 'Дома из бруса под ключ'),
(192, 49, '_header__title', 'field_63343dc64716a'),
(193, 49, 'top__bg', '26'),
(194, 49, '_top__bg', 'field_633444385ce53'),
(195, 49, 'header__sale', '28'),
(196, 49, '_header__sale', 'field_6334436dd3b0f'),
(197, 49, 'main__title', 'Строительство домов и бань из строганного и профилированного бруса'),
(198, 49, '_main__title', 'field_63344920b500c'),
(199, 49, 'main__text', '<div>\r\n<div>За <strong>10 лет</strong> мы возвели больше <strong>250 домов</strong> и бань из бруса.</div>\r\n&nbsp;\r\n<div>Имеем большой опыт в строительстве.</div>\r\n<div><em>Гарантируем качество и надежность всех построенных нами объектов.</em></div>\r\n&nbsp;\r\n<div><strong>ГАРАНТИЯ НА ДОМА И БАНИ ИЗ БРУСА 3 ГОДА!</strong></div>\r\n</div>\r\n&nbsp;'),
(200, 49, '_main__text', 'field_633449a8b500d'),
(201, 49, 'gallery__inner', '[gallery size=\"full\" columns=\"4\" ids=\"40,42,43,44,45,46,47,41\" link=\"file\"]'),
(202, 49, '_gallery__inner', 'field_6334537d87fd8'),
(203, 2, 'gallery__title', 'Фотографии наших домов'),
(204, 2, '_gallery__title', 'field_63345c78179b0'),
(205, 2, 'gallery__text', 'Смотрите все реализаванные проекты нашей команды!'),
(206, 2, '_gallery__text', 'field_63345cc397efc'),
(207, 52, 'header__name', 'Timber House'),
(208, 52, '_header__name', 'field_63343c9b724e5'),
(209, 52, 'phone', '+380 (98) 298-24-08'),
(210, 52, '_phone', 'field_63343d284e2ad'),
(211, 52, 'header__title', 'Дома из бруса под ключ'),
(212, 52, '_header__title', 'field_63343dc64716a'),
(213, 52, 'top__bg', '26'),
(214, 52, '_top__bg', 'field_633444385ce53'),
(215, 52, 'header__sale', '28'),
(216, 52, '_header__sale', 'field_6334436dd3b0f'),
(217, 52, 'main__title', 'Строительство домов и бань из строганного и профилированного бруса'),
(218, 52, '_main__title', 'field_63344920b500c'),
(219, 52, 'main__text', '<div>\r\n<div>За <strong>10 лет</strong> мы возвели больше <strong>250 домов</strong> и бань из бруса.</div>\r\n&nbsp;\r\n<div>Имеем большой опыт в строительстве.</div>\r\n<div><em>Гарантируем качество и надежность всех построенных нами объектов.</em></div>\r\n&nbsp;\r\n<div><strong>ГАРАНТИЯ НА ДОМА И БАНИ ИЗ БРУСА 3 ГОДА!</strong></div>\r\n</div>\r\n&nbsp;'),
(220, 52, '_main__text', 'field_633449a8b500d'),
(221, 52, 'gallery__inner', '[gallery size=\"full\" columns=\"4\" ids=\"40,42,43,44,45,46,47,41\" link=\"file\"]'),
(222, 52, '_gallery__inner', 'field_6334537d87fd8'),
(223, 52, 'gallery__title', 'Фотографии наших домов'),
(224, 52, '_gallery__title', 'field_63345c78179b0'),
(225, 52, 'gallery__text', 'Смотрите все реализаванные проекты нашей команды!'),
(226, 52, '_gallery__text', 'field_63345cc397efc'),
(227, 2, 'footer__email', 'myemail7@gmail.com'),
(228, 2, '_footer__email', 'field_63345e286c200'),
(229, 55, 'header__name', 'Timber House'),
(230, 55, '_header__name', 'field_63343c9b724e5'),
(231, 55, 'phone', '+380 (98) 298-24-08'),
(232, 55, '_phone', 'field_63343d284e2ad'),
(233, 55, 'header__title', 'Дома из бруса под ключ'),
(234, 55, '_header__title', 'field_63343dc64716a'),
(235, 55, 'top__bg', '26'),
(236, 55, '_top__bg', 'field_633444385ce53'),
(237, 55, 'header__sale', '28'),
(238, 55, '_header__sale', 'field_6334436dd3b0f'),
(239, 55, 'main__title', 'Строительство домов и бань из строганного и профилированного бруса'),
(240, 55, '_main__title', 'field_63344920b500c'),
(241, 55, 'main__text', '<div>\r\n<div>За <strong>10 лет</strong> мы возвели больше <strong>250 домов</strong> и бань из бруса.</div>\r\n&nbsp;\r\n<div>Имеем большой опыт в строительстве.</div>\r\n<div><em>Гарантируем качество и надежность всех построенных нами объектов.</em></div>\r\n&nbsp;\r\n<div><strong>ГАРАНТИЯ НА ДОМА И БАНИ ИЗ БРУСА 3 ГОДА!</strong></div>\r\n</div>\r\n&nbsp;'),
(242, 55, '_main__text', 'field_633449a8b500d'),
(243, 55, 'gallery__inner', '[gallery size=\"full\" columns=\"4\" ids=\"40,42,43,44,45,46,47,41\" link=\"file\"]'),
(244, 55, '_gallery__inner', 'field_6334537d87fd8'),
(245, 55, 'gallery__title', 'Фотографии наших домов'),
(246, 55, '_gallery__title', 'field_63345c78179b0'),
(247, 55, 'gallery__text', 'Смотрите все реализаванные проекты нашей команды!'),
(248, 55, '_gallery__text', 'field_63345cc397efc'),
(249, 55, 'footer__email', 'myemail7@gmail.com'),
(250, 55, '_footer__email', 'field_63345e286c200'),
(251, 58, '_wp_attached_file', '2022/09/Каталог_Фурнитура__2020_web.pdf'),
(252, 58, '_wp_attachment_metadata', 'a:1:{s:8:\"filesize\";i:3365719;}'),
(253, 2, 'download__link', '58'),
(254, 2, '_download__link', 'field_6334ec7a530af'),
(255, 59, 'header__name', 'Timber House'),
(256, 59, '_header__name', 'field_63343c9b724e5'),
(257, 59, 'phone', '+380 (98) 298-24-08'),
(258, 59, '_phone', 'field_63343d284e2ad'),
(259, 59, 'header__title', 'Дома из бруса под ключ'),
(260, 59, '_header__title', 'field_63343dc64716a'),
(261, 59, 'top__bg', '26'),
(262, 59, '_top__bg', 'field_633444385ce53'),
(263, 59, 'header__sale', '28'),
(264, 59, '_header__sale', 'field_6334436dd3b0f'),
(265, 59, 'main__title', 'Строительство домов и бань из строганного и профилированного бруса'),
(266, 59, '_main__title', 'field_63344920b500c'),
(267, 59, 'main__text', '<div>\r\n<div>За <strong>10 лет</strong> мы возвели больше <strong>250 домов</strong> и бань из бруса.</div>\r\n&nbsp;\r\n<div>Имеем большой опыт в строительстве.</div>\r\n<div><em>Гарантируем качество и надежность всех построенных нами объектов.</em></div>\r\n&nbsp;\r\n<div><strong>ГАРАНТИЯ НА ДОМА И БАНИ ИЗ БРУСА 3 ГОДА!</strong></div>\r\n</div>\r\n&nbsp;'),
(268, 59, '_main__text', 'field_633449a8b500d'),
(269, 59, 'gallery__inner', '[gallery size=\"full\" columns=\"4\" ids=\"40,42,43,44,45,46,47,41\" link=\"file\"]'),
(270, 59, '_gallery__inner', 'field_6334537d87fd8'),
(271, 59, 'gallery__title', 'Фотографии наших домов'),
(272, 59, '_gallery__title', 'field_63345c78179b0'),
(273, 59, 'gallery__text', 'Смотрите все реализаванные проекты нашей команды!'),
(274, 59, '_gallery__text', 'field_63345cc397efc'),
(275, 59, 'footer__email', 'myemail7@gmail.com'),
(276, 59, '_footer__email', 'field_63345e286c200'),
(277, 59, 'download__link', '58'),
(278, 59, '_download__link', 'field_6334ec7a530af'),
(279, 1, '_edit_lock', '1664490350:1'),
(280, 2, 'project__item', 'a:3:{i:0;s:1:\"1\";i:1;s:2:\"67\";i:2;s:2:\"91\";}'),
(281, 2, '_project__item', 'field_6334ef5dccf92'),
(282, 62, 'header__name', 'Timber House'),
(283, 62, '_header__name', 'field_63343c9b724e5'),
(284, 62, 'phone', '+380 (98) 298-24-08'),
(285, 62, '_phone', 'field_63343d284e2ad'),
(286, 62, 'header__title', 'Дома из бруса под ключ'),
(287, 62, '_header__title', 'field_63343dc64716a'),
(288, 62, 'top__bg', '26'),
(289, 62, '_top__bg', 'field_633444385ce53'),
(290, 62, 'header__sale', '28'),
(291, 62, '_header__sale', 'field_6334436dd3b0f'),
(292, 62, 'main__title', 'Строительство домов и бань из строганного и профилированного бруса'),
(293, 62, '_main__title', 'field_63344920b500c'),
(294, 62, 'main__text', '<div>\r\n<div>За <strong>10 лет</strong> мы возвели больше <strong>250 домов</strong> и бань из бруса.</div>\r\n&nbsp;\r\n<div>Имеем большой опыт в строительстве.</div>\r\n<div><em>Гарантируем качество и надежность всех построенных нами объектов.</em></div>\r\n&nbsp;\r\n<div><strong>ГАРАНТИЯ НА ДОМА И БАНИ ИЗ БРУСА 3 ГОДА!</strong></div>\r\n</div>\r\n&nbsp;'),
(295, 62, '_main__text', 'field_633449a8b500d'),
(296, 62, 'gallery__inner', '[gallery size=\"full\" columns=\"4\" ids=\"40,42,43,44,45,46,47,41\" link=\"file\"]'),
(297, 62, '_gallery__inner', 'field_6334537d87fd8'),
(298, 62, 'gallery__title', 'Фотографии наших домов'),
(299, 62, '_gallery__title', 'field_63345c78179b0'),
(300, 62, 'gallery__text', 'Смотрите все реализаванные проекты нашей команды!'),
(301, 62, '_gallery__text', 'field_63345cc397efc'),
(302, 62, 'footer__email', 'myemail7@gmail.com'),
(303, 62, '_footer__email', 'field_63345e286c200'),
(304, 62, 'download__link', '58'),
(305, 62, '_download__link', 'field_6334ec7a530af'),
(306, 62, 'project__item', 'a:1:{i:0;s:1:\"1\";}'),
(307, 62, '_project__item', 'field_6334ef5dccf92'),
(308, 1, '_edit_last', '1'),
(315, 67, '_edit_lock', '1664490687:1'),
(318, 69, 'header__name', 'Timber House'),
(319, 69, '_header__name', 'field_63343c9b724e5'),
(320, 69, 'phone', '+380 (98) 298-24-08'),
(321, 69, '_phone', 'field_63343d284e2ad'),
(322, 69, 'header__title', 'Дома из бруса под ключ'),
(323, 69, '_header__title', 'field_63343dc64716a'),
(324, 69, 'top__bg', '26'),
(325, 69, '_top__bg', 'field_633444385ce53'),
(326, 69, 'header__sale', '28'),
(327, 69, '_header__sale', 'field_6334436dd3b0f'),
(328, 69, 'main__title', 'Строительство домов и бань из строганного и профилированного бруса'),
(329, 69, '_main__title', 'field_63344920b500c'),
(330, 69, 'main__text', '<div>\r\n<div>За <strong>10 лет</strong> мы возвели больше <strong>250 домов</strong> и бань из бруса.</div>\r\n&nbsp;\r\n<div>Имеем большой опыт в строительстве.</div>\r\n<div><em>Гарантируем качество и надежность всех построенных нами объектов.</em></div>\r\n&nbsp;\r\n<div><strong>ГАРАНТИЯ НА ДОМА И БАНИ ИЗ БРУСА 3 ГОДА!</strong></div>\r\n</div>\r\n&nbsp;'),
(331, 69, '_main__text', 'field_633449a8b500d'),
(332, 69, 'gallery__inner', '[gallery size=\"full\" columns=\"4\" ids=\"40,42,43,44,45,46,47,41\" link=\"file\"]'),
(333, 69, '_gallery__inner', 'field_6334537d87fd8'),
(334, 69, 'gallery__title', 'Фотографии наших домов'),
(335, 69, '_gallery__title', 'field_63345c78179b0'),
(336, 69, 'gallery__text', 'Смотрите все реализаванные проекты нашей команды!'),
(337, 69, '_gallery__text', 'field_63345cc397efc'),
(338, 69, 'footer__email', 'myemail7@gmail.com'),
(339, 69, '_footer__email', 'field_63345e286c200'),
(340, 69, 'download__link', '58'),
(341, 69, '_download__link', 'field_6334ec7a530af'),
(342, 69, 'project__item', 'a:2:{i:0;s:1:\"1\";i:1;s:2:\"67\";}'),
(343, 69, '_project__item', 'field_6334ef5dccf92'),
(344, 71, 'header__name', 'Timber House'),
(345, 71, '_header__name', 'field_63343c9b724e5'),
(346, 71, 'phone', '+380 (98) 298-24-08'),
(347, 71, '_phone', 'field_63343d284e2ad'),
(348, 71, 'header__title', 'Дома из бруса под ключ'),
(349, 71, '_header__title', 'field_63343dc64716a'),
(350, 71, 'top__bg', '26'),
(351, 71, '_top__bg', 'field_633444385ce53'),
(352, 71, 'header__sale', '28'),
(353, 71, '_header__sale', 'field_6334436dd3b0f'),
(354, 71, 'main__title', 'Строительство домов и бань из строганного и профилированного бруса'),
(355, 71, '_main__title', 'field_63344920b500c'),
(356, 71, 'main__text', '<div>\r\n<div>За <strong>10 лет</strong> мы возвели больше <strong>250 домов</strong> и бань из бруса.</div>\r\n&nbsp;\r\n<div>Имеем большой опыт в строительстве.</div>\r\n<div><em>Гарантируем качество и надежность всех построенных нами объектов.</em></div>\r\n&nbsp;\r\n<div><strong>ГАРАНТИЯ НА ДОМА И БАНИ ИЗ БРУСА 3 ГОДА!</strong></div>\r\n</div>\r\n&nbsp;'),
(357, 71, '_main__text', 'field_633449a8b500d'),
(358, 71, 'gallery__inner', '[gallery size=\"full\" columns=\"4\" ids=\"40,42,43,44,45,46,47,41\" link=\"file\"]'),
(359, 71, '_gallery__inner', 'field_6334537d87fd8'),
(360, 71, 'gallery__title', 'Фотографии наших домов'),
(361, 71, '_gallery__title', 'field_63345c78179b0'),
(362, 71, 'gallery__text', 'Смотрите все реализаванные проекты нашей команды!'),
(363, 71, '_gallery__text', 'field_63345cc397efc'),
(364, 71, 'footer__email', 'myemail7@gmail.com'),
(365, 71, '_footer__email', 'field_63345e286c200'),
(366, 71, 'download__link', '58'),
(367, 71, '_download__link', 'field_6334ec7a530af'),
(368, 71, 'project__item', 'a:2:{i:0;s:1:\"1\";i:1;s:2:\"67\";}'),
(369, 71, '_project__item', 'field_6334ef5dccf92'),
(370, 72, 'header__name', 'Timber House'),
(371, 72, '_header__name', 'field_63343c9b724e5'),
(372, 72, 'phone', '+380 (98) 298-24-08'),
(373, 72, '_phone', 'field_63343d284e2ad'),
(374, 72, 'header__title', 'Дома из бруса под ключ'),
(375, 72, '_header__title', 'field_63343dc64716a'),
(376, 72, 'top__bg', '26'),
(377, 72, '_top__bg', 'field_633444385ce53'),
(378, 72, 'header__sale', '28'),
(379, 72, '_header__sale', 'field_6334436dd3b0f'),
(380, 72, 'main__title', 'Строительство домов и бань из строганного и профилированного бруса'),
(381, 72, '_main__title', 'field_63344920b500c'),
(382, 72, 'main__text', '<div>\r\n<div>За <strong>10 лет</strong> мы возвели больше <strong>250 домов</strong> и бань из бруса.</div>\r\n&nbsp;\r\n<div>Имеем большой опыт в строительстве.</div>\r\n<div><em>Гарантируем качество и надежность всех построенных нами объектов.</em></div>\r\n&nbsp;\r\n<div><strong>ГАРАНТИЯ НА ДОМА И БАНИ ИЗ БРУСА 3 ГОДА!</strong></div>\r\n</div>\r\n&nbsp;'),
(383, 72, '_main__text', 'field_633449a8b500d'),
(384, 72, 'gallery__inner', '[gallery size=\"full\" columns=\"4\" ids=\"40,42,43,44,45,46,47,41\" link=\"file\"]'),
(385, 72, '_gallery__inner', 'field_6334537d87fd8'),
(386, 72, 'gallery__title', 'Фотографии наших домов'),
(387, 72, '_gallery__title', 'field_63345c78179b0'),
(388, 72, 'gallery__text', 'Смотрите все реализаванные проекты нашей команды!'),
(389, 72, '_gallery__text', 'field_63345cc397efc'),
(390, 72, 'footer__email', 'myemail7@gmail.com'),
(391, 72, '_footer__email', 'field_63345e286c200'),
(392, 72, 'download__link', '58'),
(393, 72, '_download__link', 'field_6334ec7a530af'),
(394, 72, 'project__item', 'a:2:{i:0;s:1:\"1\";i:1;s:2:\"67\";}'),
(395, 72, '_project__item', 'field_6334ef5dccf92'),
(396, 73, '_edit_last', '1'),
(397, 73, '_edit_lock', '1664489848:1'),
(402, 1, 'название_проекта', 'Привет мир!'),
(403, 1, '_название_проекта', 'field_63360957a7e7c'),
(404, 75, 'название_проекта', 'Привет мир!'),
(405, 75, '_название_проекта', 'field_63360957a7e7c'),
(408, 1, 'project__name', 'Дом №1'),
(409, 1, '_project__name', 'field_63360957a7e7c'),
(410, 76, 'название_проекта', 'Привет мир!'),
(411, 76, '_название_проекта', 'field_63360957a7e7c'),
(412, 76, 'project__name', 'Привет Мир'),
(413, 76, '_project__name', 'field_63360957a7e7c'),
(414, 2, 'project__title', 'Все проекты домов из бруса'),
(415, 2, '_project__title', 'field_6336101ef20e2'),
(416, 78, 'header__name', 'Timber House'),
(417, 78, '_header__name', 'field_63343c9b724e5'),
(418, 78, 'phone', '+380 (98) 298-24-08'),
(419, 78, '_phone', 'field_63343d284e2ad'),
(420, 78, 'header__title', 'Дома из бруса под ключ'),
(421, 78, '_header__title', 'field_63343dc64716a'),
(422, 78, 'top__bg', '26'),
(423, 78, '_top__bg', 'field_633444385ce53'),
(424, 78, 'header__sale', '28'),
(425, 78, '_header__sale', 'field_6334436dd3b0f'),
(426, 78, 'main__title', 'Строительство домов и бань из строганного и профилированного бруса'),
(427, 78, '_main__title', 'field_63344920b500c'),
(428, 78, 'main__text', '<div>\r\n<div>За <strong>10 лет</strong> мы возвели больше <strong>250 домов</strong> и бань из бруса.</div>\r\n&nbsp;\r\n<div>Имеем большой опыт в строительстве.</div>\r\n<div><em>Гарантируем качество и надежность всех построенных нами объектов.</em></div>\r\n&nbsp;\r\n<div><strong>ГАРАНТИЯ НА ДОМА И БАНИ ИЗ БРУСА 3 ГОДА!</strong></div>\r\n</div>\r\n&nbsp;'),
(429, 78, '_main__text', 'field_633449a8b500d'),
(430, 78, 'gallery__inner', '[gallery size=\"full\" columns=\"4\" ids=\"40,42,43,44,45,46,47,41\" link=\"file\"]'),
(431, 78, '_gallery__inner', 'field_6334537d87fd8'),
(432, 78, 'gallery__title', 'Фотографии наших домов'),
(433, 78, '_gallery__title', 'field_63345c78179b0'),
(434, 78, 'gallery__text', 'Смотрите все реализаванные проекты нашей команды!'),
(435, 78, '_gallery__text', 'field_63345cc397efc'),
(436, 78, 'footer__email', 'myemail7@gmail.com'),
(437, 78, '_footer__email', 'field_63345e286c200'),
(438, 78, 'download__link', '58'),
(439, 78, '_download__link', 'field_6334ec7a530af'),
(440, 78, 'project__item', 'a:2:{i:0;s:1:\"1\";i:1;s:2:\"67\";}'),
(441, 78, '_project__item', 'field_6334ef5dccf92'),
(442, 78, 'project__title', 'Все проекты домов из бруса'),
(443, 78, '_project__title', 'field_6336101ef20e2'),
(446, 1, 'project__size', 'Размер дома: <strong>6 х 6</strong>'),
(447, 1, '_project__size', 'field_6336113cdd9e1'),
(448, 80, 'название_проекта', 'Привет мир!'),
(449, 80, '_название_проекта', 'field_63360957a7e7c'),
(450, 80, 'project__name', 'Дом №1'),
(451, 80, '_project__name', 'field_63360957a7e7c'),
(452, 80, 'project__size', 'Размер дома: <strong>6 х 6</strong>'),
(453, 80, '_project__size', 'field_6336113cdd9e1'),
(454, 85, '_wp_attached_file', '2022/09/project1.jpg'),
(455, 85, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:667;s:4:\"file\";s:20:\"2022/09/project1.jpg\";s:8:\"filesize\";i:314813;s:5:\"sizes\";a:3:{s:6:\"medium\";a:5:{s:4:\"file\";s:20:\"project1-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:38335;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:20:\"project1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:27595;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:20:\"project1-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:136014;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1663676669\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(456, 85, '_wp_attachment_image_alt', 'Фото дома 1'),
(457, 86, '_wp_attached_file', '2022/09/schema1.jpg'),
(458, 86, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:991;s:6:\"height\";i:543;s:4:\"file\";s:19:\"2022/09/schema1.jpg\";s:8:\"filesize\";i:71949;s:5:\"sizes\";a:3:{s:6:\"medium\";a:5:{s:4:\"file\";s:19:\"schema1-300x164.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:164;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:22366;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:19:\"schema1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:18114;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:19:\"schema1-768x421.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:421;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:47856;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1663676787\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(459, 86, '_wp_attachment_image_alt', 'Схема дома 1'),
(462, 1, 'project__area', 'Общая площадь дома: <strong>54 кв.м</strong>'),
(463, 1, '_project__area', 'field_633616af6b8c8'),
(464, 1, 'project__price', 'Стоимость: <strong>399 000 рублей</strong>'),
(465, 1, '_project__price', 'field_6336170b6b8c9'),
(466, 1, 'project__images-item1', '85'),
(467, 1, '_project__images-item1', 'field_6336174b6b8ca'),
(468, 1, 'project__images-item2', '86'),
(469, 1, '_project__images-item2', 'field_6336190e6b8cb'),
(470, 87, 'название_проекта', 'Привет мир!'),
(471, 87, '_название_проекта', 'field_63360957a7e7c'),
(472, 87, 'project__name', 'Дом №1'),
(473, 87, '_project__name', 'field_63360957a7e7c'),
(474, 87, 'project__size', 'Размер дома: <strong>6 х 6</strong>'),
(475, 87, '_project__size', 'field_6336113cdd9e1'),
(476, 87, 'project__area', 'Общая площадь дома: <strong>54 кв.м</strong>'),
(477, 87, '_project__area', 'field_633616af6b8c8'),
(478, 87, 'project__price', 'Стоимость: <strong>399 000 рублей</strong>'),
(479, 87, '_project__price', 'field_6336170b6b8c9'),
(480, 87, 'project__images-item1', '85'),
(481, 87, '_project__images-item1', 'field_6336174b6b8ca'),
(482, 87, 'project__images-item2', '86'),
(483, 87, '_project__images-item2', 'field_6336190e6b8cb'),
(484, 88, '_wp_attached_file', '2022/09/project2.jpg'),
(485, 88, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:667;s:4:\"file\";s:20:\"2022/09/project2.jpg\";s:8:\"filesize\";i:346406;s:5:\"sizes\";a:3:{s:6:\"medium\";a:5:{s:4:\"file\";s:20:\"project2-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:40996;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:20:\"project2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:28781;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:20:\"project2-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:152043;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1663676881\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(486, 88, '_wp_attachment_image_alt', 'Фото дома 2'),
(487, 89, '_wp_attached_file', '2022/09/schema2.jpg'),
(488, 89, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1004;s:6:\"height\";i:669;s:4:\"file\";s:19:\"2022/09/schema2.jpg\";s:8:\"filesize\";i:82842;s:5:\"sizes\";a:3:{s:6:\"medium\";a:5:{s:4:\"file\";s:19:\"schema2-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:23305;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:19:\"schema2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:19045;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:19:\"schema2-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:50618;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1663676922\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(489, 89, '_wp_attachment_image_alt', 'Схема дома 2'),
(492, 67, '_edit_last', '1'),
(495, 67, 'project__name', 'Дом №2'),
(496, 67, '_project__name', 'field_63360957a7e7c'),
(497, 67, 'project__size', 'Размер дома: <strong>8 х 8</strong>'),
(498, 67, '_project__size', 'field_6336113cdd9e1'),
(499, 67, 'project__area', 'Общая площадь дома: <strong>64 кв.м</strong>'),
(500, 67, '_project__area', 'field_633616af6b8c8'),
(501, 67, 'project__price', 'Стоимость: <strong>549 000 рублей</strong>'),
(502, 67, '_project__price', 'field_6336170b6b8c9'),
(503, 67, 'project__images-item1', '88'),
(504, 67, '_project__images-item1', 'field_6336174b6b8ca'),
(505, 67, 'project__images-item2', '89'),
(506, 67, '_project__images-item2', 'field_6336190e6b8cb'),
(507, 90, 'project__name', 'Дом №2'),
(508, 90, '_project__name', 'field_63360957a7e7c'),
(509, 90, 'project__size', 'Размер дома: <strong>8 х 8</strong>'),
(510, 90, '_project__size', 'field_6336113cdd9e1'),
(511, 90, 'project__area', 'Общая площадь дома: <strong>64 кв.м</strong>'),
(512, 90, '_project__area', 'field_633616af6b8c8'),
(513, 90, 'project__price', 'Стоимость: <strong>549 000 рублей</strong>'),
(514, 90, '_project__price', 'field_6336170b6b8c9'),
(515, 90, 'project__images-item1', '88'),
(516, 90, '_project__images-item1', 'field_6336174b6b8ca'),
(517, 90, 'project__images-item2', '89'),
(518, 90, '_project__images-item2', 'field_6336190e6b8cb'),
(519, 91, '_edit_lock', '1664491080:1'),
(520, 92, '_wp_attached_file', '2022/09/project3.jpg'),
(521, 92, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:667;s:4:\"file\";s:20:\"2022/09/project3.jpg\";s:8:\"filesize\";i:329150;s:5:\"sizes\";a:3:{s:6:\"medium\";a:5:{s:4:\"file\";s:20:\"project3-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:40264;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:20:\"project3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:28228;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:20:\"project3-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:145776;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1663677012\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(522, 92, '_wp_attachment_image_alt', 'Фото дома 3'),
(523, 93, '_wp_attached_file', '2022/09/schema3.jpg'),
(524, 93, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1008;s:6:\"height\";i:512;s:4:\"file\";s:19:\"2022/09/schema3.jpg\";s:8:\"filesize\";i:73363;s:5:\"sizes\";a:3:{s:6:\"medium\";a:5:{s:4:\"file\";s:19:\"schema3-300x152.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:152;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:22075;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:19:\"schema3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:18391;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:19:\"schema3-768x390.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:390;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:45961;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1663677043\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(525, 93, '_wp_attachment_image_alt', 'Схема дома 3'),
(528, 91, '_edit_last', '1'),
(529, 91, '_pingme', '1'),
(530, 91, '_encloseme', '1'),
(531, 91, 'project__name', 'Дом №3'),
(532, 91, '_project__name', 'field_63360957a7e7c'),
(533, 91, 'project__size', 'Размер дома: <strong>9 х 9</strong>'),
(534, 91, '_project__size', 'field_6336113cdd9e1'),
(535, 91, 'project__area', 'Общая площадь дома: <strong>81 кв. м</strong>'),
(536, 91, '_project__area', 'field_633616af6b8c8'),
(537, 91, 'project__price', 'Стоимость: <strong>699 000 рублей</strong>'),
(538, 91, '_project__price', 'field_6336170b6b8c9'),
(539, 91, 'project__images-item1', '92'),
(540, 91, '_project__images-item1', 'field_6336174b6b8ca'),
(541, 91, 'project__images-item2', '93'),
(542, 91, '_project__images-item2', 'field_6336190e6b8cb'),
(543, 95, 'project__name', 'Дом №3'),
(544, 95, '_project__name', 'field_63360957a7e7c'),
(545, 95, 'project__size', 'Размер дома: <strong>9 х 9</strong>'),
(546, 95, '_project__size', 'field_6336113cdd9e1'),
(547, 95, 'project__area', 'Общая площадь дома: <strong>81 кв. м</strong>'),
(548, 95, '_project__area', 'field_633616af6b8c8'),
(549, 95, 'project__price', 'Стоимость: <strong>699 000 рублей</strong>'),
(550, 95, '_project__price', 'field_6336170b6b8c9'),
(551, 95, 'project__images-item1', '92'),
(552, 95, '_project__images-item1', 'field_6336174b6b8ca'),
(553, 95, 'project__images-item2', '93'),
(554, 95, '_project__images-item2', 'field_6336190e6b8cb'),
(555, 96, 'header__name', 'Timber House'),
(556, 96, '_header__name', 'field_63343c9b724e5'),
(557, 96, 'phone', '+380 (98) 298-24-08'),
(558, 96, '_phone', 'field_63343d284e2ad'),
(559, 96, 'header__title', 'Дома из бруса под ключ'),
(560, 96, '_header__title', 'field_63343dc64716a'),
(561, 96, 'top__bg', '26'),
(562, 96, '_top__bg', 'field_633444385ce53'),
(563, 96, 'header__sale', '28'),
(564, 96, '_header__sale', 'field_6334436dd3b0f'),
(565, 96, 'main__title', 'Строительство домов и бань из строганного и профилированного бруса'),
(566, 96, '_main__title', 'field_63344920b500c'),
(567, 96, 'main__text', '<div>\r\n<div>За <strong>10 лет</strong> мы возвели больше <strong>250 домов</strong> и бань из бруса.</div>\r\n&nbsp;\r\n<div>Имеем большой опыт в строительстве.</div>\r\n<div><em>Гарантируем качество и надежность всех построенных нами объектов.</em></div>\r\n&nbsp;\r\n<div><strong>ГАРАНТИЯ НА ДОМА И БАНИ ИЗ БРУСА 3 ГОДА!</strong></div>\r\n</div>\r\n&nbsp;'),
(568, 96, '_main__text', 'field_633449a8b500d'),
(569, 96, 'gallery__inner', '[gallery size=\"full\" columns=\"4\" ids=\"40,42,43,44,45,46,47,41\" link=\"file\"]'),
(570, 96, '_gallery__inner', 'field_6334537d87fd8'),
(571, 96, 'gallery__title', 'Фотографии наших домов'),
(572, 96, '_gallery__title', 'field_63345c78179b0'),
(573, 96, 'gallery__text', 'Смотрите все реализаванные проекты нашей команды!'),
(574, 96, '_gallery__text', 'field_63345cc397efc'),
(575, 96, 'footer__email', 'myemail7@gmail.com'),
(576, 96, '_footer__email', 'field_63345e286c200'),
(577, 96, 'download__link', '58'),
(578, 96, '_download__link', 'field_6334ec7a530af'),
(579, 96, 'project__item', 'a:3:{i:0;s:1:\"1\";i:1;s:2:\"67\";i:2;s:2:\"91\";}'),
(580, 96, '_project__item', 'field_6334ef5dccf92'),
(581, 96, 'project__title', 'Все проекты домов из бруса'),
(582, 96, '_project__title', 'field_6336101ef20e2');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE `wp_posts` (
  `ID` bigint UNSIGNED NOT NULL,
  `post_author` bigint UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2022-09-27 00:04:38', '2022-09-26 21:04:38', '<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2></h2>\n<!-- /wp:heading -->', 'Дом1', '', 'publish', 'open', 'open', '', '%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80', '', '', '2022-09-30 01:25:50', '2022-09-29 22:25:50', '', 0, 'http://timber-house/?p=1', 0, 'post', '', 1),
(2, 1, '2022-09-27 00:04:38', '2022-09-26 21:04:38', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://timber-house/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная страница', '', 'publish', 'closed', 'closed', '', 'sample-page', '', '', '2022-09-30 01:41:06', '2022-09-29 22:41:06', '', 0, 'http://timber-house/?page_id=2', 0, 'page', '', 0),
(3, 1, '2022-09-27 00:04:38', '2022-09-26 21:04:38', '<!-- wp:heading --><h2>Кто мы</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Наш адрес сайта: http://timber-house.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Комментарии</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если посетитель оставляет комментарий на сайте, мы собираем данные указанные в форме комментария, а также IP адрес посетителя и данные user-agent браузера с целью определения спама.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Анонимизированная строка создаваемая из вашего адреса email (\"хеш\") может предоставляться сервису Gravatar, чтобы определить используете ли вы его. Политика конфиденциальности Gravatar доступна здесь: https://automattic.com/privacy/ . После одобрения комментария ваше изображение профиля будет видимым публично в контексте вашего комментария.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Медиафайлы</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если вы зарегистрированный пользователь и загружаете фотографии на сайт, вам возможно следует избегать загрузки изображений с метаданными EXIF, так как они могут содержать данные вашего месторасположения по GPS. Посетители могут извлечь эту информацию скачав изображения с сайта.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куки</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если вы оставляете комментарий на нашем сайте, вы можете включить сохранение вашего имени, адреса email и вебсайта в куки. Это делается для вашего удобства, чтобы не заполнять данные снова при повторном комментировании. Эти куки хранятся в течение одного года.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Если у вас есть учетная запись на сайте и вы войдете в неё, мы установим временный куки для определения поддержки куки вашим браузером, куки не содержит никакой личной информации и удаляется при закрытии вашего браузера.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При входе в учетную запись мы также устанавливаем несколько куки с данными входа и настройками экрана. Куки входа хранятся в течение двух дней, куки с настройками экрана - год. Если вы выберете возможность \"Запомнить меня\", данные о входе будут сохраняться в течение двух недель. При выходе из учетной записи куки входа будут удалены.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При редактировании или публикации статьи в браузере будет сохранен дополнительный куки, он не содержит персональных данных и содержит только ID записи отредактированной вами, истекает через 1 день.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Встраиваемое содержимое других вебсайтов</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Статьи на этом сайте могут включать встраиваемое содержимое (например видео, изображения, статьи и др.), подобное содержимое ведет себя так же, как если бы посетитель зашел на другой сайт.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Эти сайты могут собирать данные о вас, использовать куки, внедрять дополнительное отслеживание третьей стороной и следить за вашим взаимодействием с внедренным содержимым, включая отслеживание взаимодействия, если у вас есть учетная запись и вы авторизовались на том сайте.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>С кем мы делимся вашими данными</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если вы запросите сброс пароля, ваш IP будет указан в email-сообщении о сбросе.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Как долго мы храним ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если вы оставляете комментарий, то сам комментарий и его метаданные сохраняются неопределенно долго. Это делается для того, чтобы определять и одобрять последующие комментарии автоматически, вместо помещения их в очередь на одобрение.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Для пользователей с регистрацией на нашем сайте мы храним ту личную информацию, которую они указывают в своем профиле. Все пользователи могут видеть, редактировать или удалить свою информацию из профиля в любое время (кроме имени пользователя). Администрация вебсайта также может видеть и изменять эту информацию.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие у вас права на ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>При наличии учетной записи на сайте или если вы оставляли комментарии, то вы можете запросить файл экспорта персональных данных, которые мы сохранили о вас, включая предоставленные вами данные. Вы также можете запросить удаление этих данных, это не включает данные, которые мы обязаны хранить в административных целях, по закону или целях безопасности.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куда отправляются ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Комментарии пользователей могут проверяться автоматическим сервисом определения спама.</p><!-- /wp:paragraph -->', 'Политика конфиденциальности', '', 'trash', 'closed', 'open', '', 'privacy-policy__trashed', '', '', '2022-09-28 02:07:58', '2022-09-27 23:07:58', '', 0, 'http://timber-house/?page_id=3', 0, 'page', '', 0),
(5, 1, '2022-09-28 01:54:11', '2022-09-27 22:54:11', '{\n    \"blogdescription\": {\n        \"value\": \"Timber House - Best houses construction team\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-09-27 22:50:33\"\n    },\n    \"blogname\": {\n        \"value\": \"Timber House\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-09-27 22:52:34\"\n    },\n    \"site_icon\": {\n        \"value\": 7,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-09-27 22:54:11\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'd5ed1616-a389-4846-b8cb-f102fc13fd84', '', '', '2022-09-28 01:54:11', '2022-09-27 22:54:11', '', 0, 'http://timber-house/?p=5', 0, 'customize_changeset', '', 0),
(6, 1, '2022-09-28 01:53:15', '2022-09-27 22:53:15', '', 'Timber House', '', 'inherit', 'open', 'closed', '', 'pngwing-com-15', '', '', '2022-09-28 01:53:58', '2022-09-27 22:53:58', '', 0, 'http://timber-house/wp-content/uploads/2022/09/pngwing.com-15.png', 0, 'attachment', 'image/png', 0),
(7, 1, '2022-09-28 01:54:04', '2022-09-27 22:54:04', 'http://timber-house/wp-content/uploads/2022/09/cropped-pngwing.com-15.png', 'cropped-pngwing.com-15.png', '', 'inherit', 'open', 'closed', '', 'cropped-pngwing-com-15-png', '', '', '2022-09-28 01:54:04', '2022-09-27 22:54:04', '', 0, 'http://timber-house/wp-content/uploads/2022/09/cropped-pngwing.com-15.png', 0, 'attachment', 'image/png', 0),
(8, 1, '2022-09-28 02:07:58', '2022-09-27 23:07:58', '<!-- wp:heading --><h2>Кто мы</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Наш адрес сайта: http://timber-house.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Комментарии</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если посетитель оставляет комментарий на сайте, мы собираем данные указанные в форме комментария, а также IP адрес посетителя и данные user-agent браузера с целью определения спама.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Анонимизированная строка создаваемая из вашего адреса email (\"хеш\") может предоставляться сервису Gravatar, чтобы определить используете ли вы его. Политика конфиденциальности Gravatar доступна здесь: https://automattic.com/privacy/ . После одобрения комментария ваше изображение профиля будет видимым публично в контексте вашего комментария.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Медиафайлы</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если вы зарегистрированный пользователь и загружаете фотографии на сайт, вам возможно следует избегать загрузки изображений с метаданными EXIF, так как они могут содержать данные вашего месторасположения по GPS. Посетители могут извлечь эту информацию скачав изображения с сайта.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куки</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если вы оставляете комментарий на нашем сайте, вы можете включить сохранение вашего имени, адреса email и вебсайта в куки. Это делается для вашего удобства, чтобы не заполнять данные снова при повторном комментировании. Эти куки хранятся в течение одного года.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Если у вас есть учетная запись на сайте и вы войдете в неё, мы установим временный куки для определения поддержки куки вашим браузером, куки не содержит никакой личной информации и удаляется при закрытии вашего браузера.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При входе в учетную запись мы также устанавливаем несколько куки с данными входа и настройками экрана. Куки входа хранятся в течение двух дней, куки с настройками экрана - год. Если вы выберете возможность \"Запомнить меня\", данные о входе будут сохраняться в течение двух недель. При выходе из учетной записи куки входа будут удалены.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При редактировании или публикации статьи в браузере будет сохранен дополнительный куки, он не содержит персональных данных и содержит только ID записи отредактированной вами, истекает через 1 день.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Встраиваемое содержимое других вебсайтов</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Статьи на этом сайте могут включать встраиваемое содержимое (например видео, изображения, статьи и др.), подобное содержимое ведет себя так же, как если бы посетитель зашел на другой сайт.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Эти сайты могут собирать данные о вас, использовать куки, внедрять дополнительное отслеживание третьей стороной и следить за вашим взаимодействием с внедренным содержимым, включая отслеживание взаимодействия, если у вас есть учетная запись и вы авторизовались на том сайте.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>С кем мы делимся вашими данными</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если вы запросите сброс пароля, ваш IP будет указан в email-сообщении о сбросе.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Как долго мы храним ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если вы оставляете комментарий, то сам комментарий и его метаданные сохраняются неопределенно долго. Это делается для того, чтобы определять и одобрять последующие комментарии автоматически, вместо помещения их в очередь на одобрение.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Для пользователей с регистрацией на нашем сайте мы храним ту личную информацию, которую они указывают в своем профиле. Все пользователи могут видеть, редактировать или удалить свою информацию из профиля в любое время (кроме имени пользователя). Администрация вебсайта также может видеть и изменять эту информацию.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие у вас права на ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>При наличии учетной записи на сайте или если вы оставляли комментарии, то вы можете запросить файл экспорта персональных данных, которые мы сохранили о вас, включая предоставленные вами данные. Вы также можете запросить удаление этих данных, это не включает данные, которые мы обязаны хранить в административных целях, по закону или целях безопасности.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куда отправляются ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Комментарии пользователей могут проверяться автоматическим сервисом определения спама.</p><!-- /wp:paragraph -->', 'Политика конфиденциальности', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2022-09-28 02:07:58', '2022-09-27 23:07:58', '', 3, 'http://timber-house/?p=8', 0, 'revision', '', 0),
(9, 1, '2022-09-28 02:08:16', '2022-09-27 23:08:16', '{\"version\": 2, \"isGlobalStylesUserThemeJSON\": true }', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-timber', '', '', '2022-09-28 02:08:16', '2022-09-27 23:08:16', '', 0, 'http://timber-house/?p=9', 0, 'wp_global_styles', '', 0),
(11, 1, '2022-09-28 02:11:32', '2022-09-27 23:11:32', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://timber-house/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-09-28 02:11:32', '2022-09-27 23:11:32', '', 2, 'http://timber-house/?p=11', 0, 'revision', '', 0),
(12, 1, '2022-09-28 02:19:30', '2022-09-27 23:19:30', 'a:8:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"2\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";s:12:\"show_in_rest\";i:0;}', 'Главная страница', '%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f-%d1%81%d1%82%d1%80%d0%b0%d0%bd%d0%b8%d1%86%d0%b0', 'publish', 'closed', 'closed', '', 'group_633383ebb929a', '', '', '2022-09-30 00:39:12', '2022-09-29 21:39:12', '', 0, 'http://timber-house/?post_type=acf-field-group&#038;p=12', 0, 'acf-field-group', '', 0),
(13, 1, '2022-09-28 02:19:30', '2022-09-27 23:19:30', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";a:1:{i:0;a:1:{i:0;a:2:{s:8:\"operator\";s:0:\"\";s:5:\"value\";s:0:\"\";}}}s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:1;}', 'Первый экран', '', 'publish', 'closed', 'closed', '', 'field_633383ec5744b', '', '', '2022-09-28 15:10:46', '2022-09-28 12:10:46', '', 12, 'http://timber-house/?post_type=acf-field&#038;p=13', 0, 'acf-field', '', 0),
(14, 1, '2022-09-28 02:28:41', '2022-09-27 23:28:41', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Основной текст', 'основной_текст', 'publish', 'closed', 'closed', '', 'field_633386800eb44', '', '', '2022-09-28 15:58:07', '2022-09-28 12:58:07', '', 12, 'http://timber-house/?post_type=acf-field&#038;p=14', 6, 'acf-field', '', 0),
(15, 1, '2022-09-28 02:28:41', '2022-09-27 23:28:41', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Фото работ', 'фото_работ', 'publish', 'closed', 'closed', '', 'field_633387180eb45', '', '', '2022-09-30 00:39:12', '2022-09-29 21:39:12', '', 12, 'http://timber-house/?post_type=acf-field&#038;p=15', 14, 'acf-field', '', 0),
(17, 1, '2022-09-28 15:25:05', '2022-09-28 12:25:05', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:48:\"Укажите название компании\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:12:\"Timber House\";s:9:\"maxlength\";i:48;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";}', 'Главное название', 'header__name', 'publish', 'closed', 'closed', '', 'field_63343c9b724e5', '', '', '2022-09-28 15:59:55', '2022-09-28 12:59:55', '', 12, 'http://timber-house/?post_type=acf-field&#038;p=17', 1, 'acf-field', '', 0),
(18, 1, '2022-09-28 15:27:31', '2022-09-28 12:27:31', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:42:\"Укажите номер телефона\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:18:\"+7 (585) 277-22-17\";s:9:\"maxlength\";i:24;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";}', 'Телефон', 'phone', 'publish', 'closed', 'closed', '', 'field_63343d284e2ad', '', '', '2022-09-28 15:59:55', '2022-09-28 12:59:55', '', 12, 'http://timber-house/?post_type=acf-field&#038;p=18', 2, 'acf-field', '', 0),
(19, 1, '2022-09-28 15:29:07', '2022-09-28 12:29:07', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:48:\"Введите описание компании\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:40:\"Дома из бруса под ключ\";s:9:\"maxlength\";i:64;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";}', 'Главный текст', 'header__title', 'publish', 'closed', 'closed', '', 'field_63343dc64716a', '', '', '2022-09-28 15:59:55', '2022-09-28 12:59:55', '', 12, 'http://timber-house/?post_type=acf-field&#038;p=19', 3, 'acf-field', '', 0),
(22, 1, '2022-09-28 15:44:34', '2022-09-28 12:44:34', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Компания «Штучки XYZ» была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://timber-house/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-09-28 15:44:34', '2022-09-28 12:44:34', '', 2, 'http://timber-house/?p=22', 0, 'revision', '', 0),
(23, 1, '2022-09-28 15:44:34', '2022-09-28 12:44:34', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Компания «Штучки XYZ» была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://timber-house/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-09-28 15:44:34', '2022-09-28 12:44:34', '', 2, 'http://timber-house/?p=23', 0, 'revision', '', 0),
(24, 1, '2022-09-28 15:55:10', '2022-09-28 12:55:10', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:31:\"Укажите картинку\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:14:\"jpg, png, webp\";s:12:\"preview_size\";s:4:\"full\";}', 'Подарок', 'header__sale', 'publish', 'closed', 'closed', '', 'field_6334436dd3b0f', '', '', '2022-09-28 16:07:32', '2022-09-28 13:07:32', '', 12, 'http://timber-house/?post_type=acf-field&#038;p=24', 5, 'acf-field', '', 0),
(25, 1, '2022-09-28 15:57:37', '2022-09-28 12:57:37', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:21:\"Укажите фон\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:14:\"jpg, png, webp\";s:12:\"preview_size\";s:4:\"full\";}', 'Фоновое изображение', 'top__bg', 'publish', 'closed', 'closed', '', 'field_633444385ce53', '', '', '2022-09-28 15:59:55', '2022-09-28 12:59:55', '', 12, 'http://timber-house/?post_type=acf-field&#038;p=25', 4, 'acf-field', '', 0),
(26, 1, '2022-09-28 16:02:36', '2022-09-28 13:02:36', '', 'Timber House project', '', 'inherit', 'open', 'closed', '', 'slider-header3', '', '', '2022-09-28 16:03:39', '2022-09-28 13:03:39', '', 2, 'http://timber-house/wp-content/uploads/2022/09/slider-header3.jpg', 0, 'attachment', 'image/jpeg', 0),
(27, 1, '2022-09-28 16:05:12', '2022-09-28 13:05:12', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Компания «Штучки XYZ» была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://timber-house/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-09-28 16:05:12', '2022-09-28 13:05:12', '', 2, 'http://timber-house/?p=27', 0, 'revision', '', 0),
(28, 1, '2022-09-28 16:07:50', '2022-09-28 13:07:50', '', 'Акция от Timber House', '', 'inherit', 'open', 'closed', '', 'sale', '', '', '2022-09-28 16:08:37', '2022-09-28 13:08:37', '', 2, 'http://timber-house/wp-content/uploads/2022/09/sale.png', 0, 'attachment', 'image/png', 0),
(29, 1, '2022-09-28 16:08:58', '2022-09-28 13:08:58', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Компания «Штучки XYZ» была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://timber-house/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-09-28 16:08:58', '2022-09-28 13:08:58', '', 2, 'http://timber-house/?p=29', 0, 'revision', '', 0),
(30, 1, '2022-09-28 16:10:40', '2022-09-28 13:10:40', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Компания «Штучки XYZ» была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://timber-house/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-09-28 16:10:40', '2022-09-28 13:10:40', '', 2, 'http://timber-house/?p=30', 0, 'revision', '', 0),
(31, 1, '2022-09-28 16:21:01', '2022-09-28 13:21:01', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:31:\"Укажите заглавие\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:29:\"Заглавие секции\";s:9:\"maxlength\";i:128;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";}', 'Заглавие', 'main__title', 'publish', 'closed', 'closed', '', 'field_63344920b500c', '', '', '2022-09-28 16:21:21', '2022-09-28 13:21:21', '', 12, 'http://timber-house/?post_type=acf-field&#038;p=31', 7, 'acf-field', '', 0),
(32, 1, '2022-09-28 16:21:01', '2022-09-28 13:21:01', 'a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:42:\"Укажите основной текст\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:40:\"Основной текст секции\";s:5:\"delay\";i:1;s:4:\"tabs\";s:3:\"all\";s:7:\"toolbar\";s:4:\"full\";s:12:\"media_upload\";i:1;}', 'Основной текст', 'main__text', 'publish', 'closed', 'closed', '', 'field_633449a8b500d', '', '', '2022-09-28 16:21:21', '2022-09-28 13:21:21', '', 12, 'http://timber-house/?post_type=acf-field&#038;p=32', 8, 'acf-field', '', 0),
(33, 1, '2022-09-28 16:28:34', '2022-09-28 13:28:34', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Компания «Штучки XYZ» была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://timber-house/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-09-28 16:28:34', '2022-09-28 13:28:34', '', 2, 'http://timber-house/?p=33', 0, 'revision', '', 0),
(35, 1, '2022-09-28 16:29:25', '2022-09-28 13:29:25', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Компания «Штучки XYZ» была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://timber-house/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-09-28 16:29:25', '2022-09-28 13:29:25', '', 2, 'http://timber-house/?p=35', 0, 'revision', '', 0),
(36, 1, '2022-09-28 16:35:22', '2022-09-28 13:35:22', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Компания «Штучки XYZ» была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://timber-house/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-09-28 16:35:22', '2022-09-28 13:35:22', '', 2, 'http://timber-house/?p=36', 0, 'revision', '', 0),
(37, 1, '2022-09-28 16:37:08', '2022-09-28 13:37:08', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Компания «Штучки XYZ» была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://timber-house/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-09-28 16:37:08', '2022-09-28 13:37:08', '', 2, 'http://timber-house/?p=37', 0, 'revision', '', 0),
(38, 1, '2022-09-28 16:39:56', '2022-09-28 13:39:56', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Компания «Штучки XYZ» была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://timber-house/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-09-28 16:39:56', '2022-09-28 13:39:56', '', 2, 'http://timber-house/?p=38', 0, 'revision', '', 0),
(39, 1, '2022-09-28 17:02:21', '2022-09-28 14:02:21', 'a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:37:\"Выберите фотографии\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:5:\"delay\";i:1;s:4:\"tabs\";s:6:\"visual\";s:7:\"toolbar\";s:4:\"full\";s:12:\"media_upload\";i:1;}', 'Фотогалерея', 'gallery__inner', 'publish', 'closed', 'closed', '', 'field_6334537d87fd8', '', '', '2022-09-30 00:39:12', '2022-09-29 21:39:12', '', 12, 'http://timber-house/?post_type=acf-field&#038;p=39', 17, 'acf-field', '', 0),
(40, 1, '2022-09-28 17:07:53', '2022-09-28 14:07:53', '', 'Проект дома 8', 'Проект дома 1', 'inherit', 'open', 'closed', '', 'item-1', '', '', '2022-09-28 17:12:11', '2022-09-28 14:12:11', '', 2, 'http://timber-house/wp-content/uploads/2022/09/item-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(41, 1, '2022-09-28 17:07:54', '2022-09-28 14:07:54', '', 'Проект дома 7', 'Проект дома 8', 'inherit', 'open', 'closed', '', 'item-2', '', '', '2022-09-28 17:12:40', '2022-09-28 14:12:40', '', 2, 'http://timber-house/wp-content/uploads/2022/09/item-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(42, 1, '2022-09-28 17:07:54', '2022-09-28 14:07:54', '', 'Проект дома 6', 'Проект дома 2', 'inherit', 'open', 'closed', '', 'item-3', '', '', '2022-09-28 17:12:16', '2022-09-28 14:12:16', '', 2, 'http://timber-house/wp-content/uploads/2022/09/item-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(43, 1, '2022-09-28 17:07:54', '2022-09-28 14:07:54', '', 'Проект дома 5', 'Проект дома 3', 'inherit', 'open', 'closed', '', 'item-4', '', '', '2022-09-28 17:12:19', '2022-09-28 14:12:19', '', 2, 'http://timber-house/wp-content/uploads/2022/09/item-4.jpg', 0, 'attachment', 'image/jpeg', 0),
(44, 1, '2022-09-28 17:07:55', '2022-09-28 14:07:55', '', 'Проект дома 4', 'Проект дома 4', 'inherit', 'open', 'closed', '', 'item-5', '', '', '2022-09-28 17:12:23', '2022-09-28 14:12:23', '', 2, 'http://timber-house/wp-content/uploads/2022/09/item-5.jpg', 0, 'attachment', 'image/jpeg', 0),
(45, 1, '2022-09-28 17:07:55', '2022-09-28 14:07:55', '', 'Проект дома 3', 'Проект дома 5', 'inherit', 'open', 'closed', '', 'item-6', '', '', '2022-09-28 17:12:29', '2022-09-28 14:12:29', '', 2, 'http://timber-house/wp-content/uploads/2022/09/item-6.jpg', 0, 'attachment', 'image/jpeg', 0),
(46, 1, '2022-09-28 17:07:56', '2022-09-28 14:07:56', '', 'Проект дома 2', 'Проект дома 6', 'inherit', 'open', 'closed', '', 'item-7', '', '', '2022-09-28 17:12:32', '2022-09-28 14:12:32', '', 2, 'http://timber-house/wp-content/uploads/2022/09/item-7.jpg', 0, 'attachment', 'image/jpeg', 0),
(47, 1, '2022-09-28 17:07:57', '2022-09-28 14:07:57', '', 'Проект дома 1', 'Проект дома 7', 'inherit', 'open', 'closed', '', 'item-8', '', '', '2022-09-28 17:12:34', '2022-09-28 14:12:34', '', 2, 'http://timber-house/wp-content/uploads/2022/09/item-8.jpg', 0, 'attachment', 'image/jpeg', 0),
(48, 1, '2022-09-28 17:15:03', '2022-09-28 14:15:03', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Компания «Штучки XYZ» была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://timber-house/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-09-28 17:15:03', '2022-09-28 14:15:03', '', 2, 'http://timber-house/?p=48', 0, 'revision', '', 0),
(49, 1, '2022-09-28 17:18:22', '2022-09-28 14:18:22', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Компания «Штучки XYZ» была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://timber-house/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-09-28 17:18:22', '2022-09-28 14:18:22', '', 2, 'http://timber-house/?p=49', 0, 'revision', '', 0),
(50, 1, '2022-09-28 17:39:50', '2022-09-28 14:39:50', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:31:\"Укажите заглавие\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:39:\"Заглавие фотогалереи\";s:9:\"maxlength\";i:128;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";}', 'Заглавие', 'gallery__title', 'publish', 'closed', 'closed', '', 'field_63345c78179b0', '', '', '2022-09-30 00:39:12', '2022-09-29 21:39:12', '', 12, 'http://timber-house/?post_type=acf-field&#038;p=50', 15, 'acf-field', '', 0),
(51, 1, '2022-09-28 17:41:17', '2022-09-28 14:41:17', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:54:\"Укажите описание фотогалереи\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:39:\"Описание фотогалереи\";s:9:\"maxlength\";i:256;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";}', 'Подзаголовок', 'gallery__text', 'publish', 'closed', 'closed', '', 'field_63345cc397efc', '', '', '2022-09-30 00:39:12', '2022-09-29 21:39:12', '', 12, 'http://timber-house/?post_type=acf-field&#038;p=51', 16, 'acf-field', '', 0),
(52, 1, '2022-09-28 17:43:26', '2022-09-28 14:43:26', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Компания «Штучки XYZ» была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://timber-house/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-09-28 17:43:26', '2022-09-28 14:43:26', '', 2, 'http://timber-house/?p=52', 0, 'revision', '', 0),
(53, 1, '2022-09-28 17:47:22', '2022-09-28 14:47:22', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Контакты', 'контакты', 'publish', 'closed', 'closed', '', 'field_63345dcf6c1ff', '', '', '2022-09-30 00:39:12', '2022-09-29 21:39:12', '', 12, 'http://timber-house/?post_type=acf-field&#038;p=53', 18, 'acf-field', '', 0),
(54, 1, '2022-09-28 17:47:22', '2022-09-28 14:47:22', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:40:\"Укажите почтовый ящик\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:18:\"yourmail@gmail.com\";s:9:\"maxlength\";i:24;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";}', 'Почта', 'footer__email', 'publish', 'closed', 'closed', '', 'field_63345e286c200', '', '', '2022-09-30 00:39:12', '2022-09-29 21:39:12', '', 12, 'http://timber-house/?post_type=acf-field&#038;p=54', 19, 'acf-field', '', 0),
(55, 1, '2022-09-28 17:50:29', '2022-09-28 14:50:29', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Компания «Штучки XYZ» была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://timber-house/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-09-28 17:50:29', '2022-09-28 14:50:29', '', 2, 'http://timber-house/?p=55', 0, 'revision', '', 0),
(56, 1, '2022-09-29 03:56:46', '2022-09-29 00:56:46', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Каталог', 'каталог', 'publish', 'closed', 'closed', '', 'field_6334ec58530ae', '', '', '2022-09-30 00:39:12', '2022-09-29 21:39:12', '', 12, 'http://timber-house/?post_type=acf-field&#038;p=56', 12, 'acf-field', '', 0),
(57, 1, '2022-09-29 03:56:46', '2022-09-29 00:56:46', 'a:10:{s:4:\"type\";s:4:\"file\";s:12:\"instructions\";s:25:\"Выберите файл\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:7:\"library\";s:3:\"all\";s:8:\"min_size\";s:0:\"\";s:8:\"max_size\";i:10;s:10:\"mime_types\";s:0:\"\";}', 'Файл каталог', 'download__link', 'publish', 'closed', 'closed', '', 'field_6334ec7a530af', '', '', '2022-09-30 00:39:12', '2022-09-29 21:39:12', '', 12, 'http://timber-house/?post_type=acf-field&#038;p=57', 13, 'acf-field', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(58, 1, '2022-09-29 04:00:06', '2022-09-29 01:00:06', '', 'Каталог_Фурнитура__2020_web', '', 'inherit', 'open', 'closed', '', '%d0%ba%d0%b0%d1%82%d0%b0%d0%bb%d0%be%d0%b3_%d1%84%d1%83%d1%80%d0%bd%d0%b8%d1%82%d1%83%d1%80%d0%b0__2020_web', '', '', '2022-09-29 04:00:06', '2022-09-29 01:00:06', '', 2, 'http://timber-house/wp-content/uploads/2022/09/Каталог_Фурнитура__2020_web.pdf', 0, 'attachment', 'application/pdf', 0),
(59, 1, '2022-09-29 04:00:23', '2022-09-29 01:00:23', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Компания «Штучки XYZ» была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://timber-house/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-09-29 04:00:23', '2022-09-29 01:00:23', '', 2, 'http://timber-house/?p=59', 0, 'revision', '', 0),
(60, 1, '2022-09-29 04:04:47', '2022-09-29 01:04:47', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Проекты домов', 'проекты_домов', 'publish', 'closed', 'closed', '', 'field_6334ef1e1d1a1', '', '', '2022-09-29 04:08:48', '2022-09-29 01:08:48', '', 12, 'http://timber-house/?post_type=acf-field&#038;p=60', 9, 'acf-field', '', 0),
(61, 1, '2022-09-29 04:08:48', '2022-09-29 01:08:48', 'a:12:{s:4:\"type\";s:12:\"relationship\";s:12:\"instructions\";s:29:\"Добавить запись\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"post_type\";a:1:{i:0;s:4:\"post\";}s:8:\"taxonomy\";s:0:\"\";s:7:\"filters\";a:3:{i:0;s:6:\"search\";i:1;s:9:\"post_type\";i:2;s:8:\"taxonomy\";}s:13:\"return_format\";s:6:\"object\";s:3:\"min\";i:1;s:3:\"max\";i:16;s:8:\"elements\";s:0:\"\";}', 'Проект запись', 'project__item', 'publish', 'closed', 'closed', '', 'field_6334ef5dccf92', '', '', '2022-09-30 00:39:12', '2022-09-29 21:39:12', '', 12, 'http://timber-house/?post_type=acf-field&#038;p=61', 11, 'acf-field', '', 0),
(62, 1, '2022-09-29 04:23:01', '2022-09-29 01:23:01', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Компания «Штучки XYZ» была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://timber-house/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-09-29 04:23:01', '2022-09-29 01:23:01', '', 2, 'http://timber-house/?p=62', 0, 'revision', '', 0),
(63, 1, '2022-09-29 04:42:16', '2022-09-29 01:42:16', '<!-- wp:paragraph -->\n<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>\n<!-- /wp:paragraph -->', 'Привет, мир!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2022-09-29 04:42:16', '2022-09-29 01:42:16', '', 1, 'http://timber-house/?p=63', 0, 'revision', '', 0),
(65, 1, '2022-09-29 04:43:29', '2022-09-29 01:43:29', '<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2></h2>\n<!-- /wp:heading -->', '', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2022-09-29 04:43:29', '2022-09-29 01:43:29', '', 1, 'http://timber-house/?p=65', 0, 'revision', '', 0),
(66, 1, '2022-09-29 04:45:55', '2022-09-29 01:45:55', '<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2></h2>\n<!-- /wp:heading -->', 'Дом1', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2022-09-29 04:45:55', '2022-09-29 01:45:55', '', 1, 'http://timber-house/?p=66', 0, 'revision', '', 0),
(67, 1, '2022-09-29 23:58:45', '2022-09-29 20:58:45', '', 'Дом2', '', 'publish', 'open', 'open', '', '%d0%b4%d0%be%d0%bc2', '', '', '2022-09-30 01:31:25', '2022-09-29 22:31:25', '', 0, 'http://timber-house/?p=67', 0, 'post', '', 0),
(68, 1, '2022-09-29 23:58:45', '2022-09-29 20:58:45', '', 'Дом2', '', 'inherit', 'closed', 'closed', '', '67-revision-v1', '', '', '2022-09-29 23:58:45', '2022-09-29 20:58:45', '', 67, 'http://timber-house/?p=68', 0, 'revision', '', 0),
(69, 1, '2022-09-30 00:01:08', '2022-09-29 21:01:08', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Компания «Штучки XYZ» была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://timber-house/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-09-30 00:01:08', '2022-09-29 21:01:08', '', 2, 'http://timber-house/?p=69', 0, 'revision', '', 0),
(70, 1, '2022-09-30 00:01:46', '2022-09-29 21:01:46', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://timber-house/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-09-30 00:01:46', '2022-09-29 21:01:46', '', 2, 'http://timber-house/?p=70', 0, 'revision', '', 0),
(71, 1, '2022-09-30 00:01:46', '2022-09-29 21:01:46', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://timber-house/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-09-30 00:01:46', '2022-09-29 21:01:46', '', 2, 'http://timber-house/?p=71', 0, 'revision', '', 0),
(72, 1, '2022-09-30 00:02:06', '2022-09-29 21:02:06', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://timber-house/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-09-30 00:02:06', '2022-09-29 21:02:06', '', 2, 'http://timber-house/?p=72', 0, 'revision', '', 0),
(73, 1, '2022-09-30 00:09:38', '2022-09-29 21:09:38', 'a:8:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:4:\"post\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";s:12:\"show_in_rest\";i:0;}', 'Записи', '%d0%b7%d0%b0%d0%bf%d0%b8%d1%81%d0%b8', 'publish', 'closed', 'closed', '', 'group_63360956e4ea8', '', '', '2022-09-30 01:19:47', '2022-09-29 22:19:47', '', 0, 'http://timber-house/?post_type=acf-field-group&#038;p=73', 0, 'acf-field-group', '', 0),
(74, 1, '2022-09-30 00:09:38', '2022-09-29 21:09:38', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:46:\"Укажите название проекта\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";i:48;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";}', 'Название проекта', 'project__name', 'publish', 'closed', 'closed', '', 'field_63360957a7e7c', '', '', '2022-09-30 00:44:53', '2022-09-29 21:44:53', '', 73, 'http://timber-house/?post_type=acf-field&#038;p=74', 0, 'acf-field', '', 0),
(75, 1, '2022-09-30 00:10:39', '2022-09-29 21:10:39', '<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2></h2>\n<!-- /wp:heading -->', 'Дом1', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2022-09-30 00:10:39', '2022-09-29 21:10:39', '', 1, 'http://timber-house/?p=75', 0, 'revision', '', 0),
(76, 1, '2022-09-30 00:23:46', '2022-09-29 21:23:46', '<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2></h2>\n<!-- /wp:heading -->', 'Дом1', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2022-09-30 00:23:46', '2022-09-29 21:23:46', '', 1, 'http://timber-house/?p=76', 0, 'revision', '', 0),
(77, 1, '2022-09-30 00:38:19', '2022-09-29 21:38:19', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:46:\"Укажите заглавие проекта\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";i:64;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";}', 'Заглавие', 'project__title', 'publish', 'closed', 'closed', '', 'field_6336101ef20e2', '', '', '2022-09-30 00:39:12', '2022-09-29 21:39:12', '', 12, 'http://timber-house/?post_type=acf-field&#038;p=77', 10, 'acf-field', '', 0),
(78, 1, '2022-09-30 00:40:09', '2022-09-29 21:40:09', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://timber-house/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-09-30 00:40:09', '2022-09-29 21:40:09', '', 2, 'http://timber-house/?p=78', 0, 'revision', '', 0),
(79, 1, '2022-09-30 00:44:53', '2022-09-29 21:44:53', 'a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:36:\"Укажите размер дома\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:22:\"Размер дома:\";s:5:\"delay\";i:1;s:4:\"tabs\";s:4:\"text\";s:12:\"media_upload\";i:0;s:7:\"toolbar\";s:4:\"full\";}', 'Размер дома', 'project__size', 'publish', 'closed', 'closed', '', 'field_6336113cdd9e1', '', '', '2022-09-30 00:48:38', '2022-09-29 21:48:38', '', 73, 'http://timber-house/?post_type=acf-field&#038;p=79', 1, 'acf-field', '', 0),
(80, 1, '2022-09-30 00:50:14', '2022-09-29 21:50:14', '<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2></h2>\n<!-- /wp:heading -->', 'Дом1', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2022-09-30 00:50:14', '2022-09-29 21:50:14', '', 1, 'http://timber-house/?p=80', 0, 'revision', '', 0),
(81, 1, '2022-09-30 01:17:18', '2022-09-29 22:17:18', 'a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:29:\"Укажите площадь\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:35:\"Общая площадь дома:\";s:5:\"delay\";i:1;s:4:\"tabs\";s:4:\"text\";s:12:\"media_upload\";i:0;s:7:\"toolbar\";s:4:\"full\";}', 'Площадь', 'project__area', 'publish', 'closed', 'closed', '', 'field_633616af6b8c8', '', '', '2022-09-30 01:17:18', '2022-09-29 22:17:18', '', 73, 'http://timber-house/?post_type=acf-field&p=81', 2, 'acf-field', '', 0),
(82, 1, '2022-09-30 01:17:18', '2022-09-29 22:17:18', 'a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:33:\"Укажите стоимость\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:19:\"Стоимость:\";s:5:\"delay\";i:1;s:4:\"tabs\";s:4:\"text\";s:12:\"media_upload\";i:0;s:7:\"toolbar\";s:4:\"full\";}', 'Стоимость', 'project__price', 'publish', 'closed', 'closed', '', 'field_6336170b6b8c9', '', '', '2022-09-30 01:17:18', '2022-09-29 22:17:18', '', 73, 'http://timber-house/?post_type=acf-field&p=82', 3, 'acf-field', '', 0),
(83, 1, '2022-09-30 01:17:18', '2022-09-29 22:17:18', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:25:\"Добавьте фото\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:14:\"jpg, png, webp\";s:12:\"preview_size\";s:4:\"full\";}', 'Фото дома', 'project__images-item1', 'publish', 'closed', 'closed', '', 'field_6336174b6b8ca', '', '', '2022-09-30 01:17:18', '2022-09-29 22:17:18', '', 73, 'http://timber-house/?post_type=acf-field&p=83', 4, 'acf-field', '', 0),
(84, 1, '2022-09-30 01:17:18', '2022-09-29 22:17:18', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:36:\"Выберите фото схемы\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:14:\"jpg, png, webp\";s:12:\"preview_size\";s:4:\"full\";}', 'Схема дома', 'project__images-item2', 'publish', 'closed', 'closed', '', 'field_6336190e6b8cb', '', '', '2022-09-30 01:17:18', '2022-09-29 22:17:18', '', 73, 'http://timber-house/?post_type=acf-field&p=84', 5, 'acf-field', '', 0),
(85, 1, '2022-09-30 01:23:17', '2022-09-29 22:23:17', 'Проект компактного дома из бруса по лучшей цене', 'project1', 'Моя подпись', 'inherit', 'open', 'closed', '', 'project1', '', '', '2022-09-30 01:25:37', '2022-09-29 22:25:37', '', 1, 'http://timber-house/wp-content/uploads/2022/09/project1.jpg', 0, 'attachment', 'image/jpeg', 0),
(86, 1, '2022-09-30 01:23:50', '2022-09-29 22:23:50', '', 'schema1', '', 'inherit', 'open', 'closed', '', 'schema1', '', '', '2022-09-30 01:24:01', '2022-09-29 22:24:01', '', 1, 'http://timber-house/wp-content/uploads/2022/09/schema1.jpg', 0, 'attachment', 'image/jpeg', 0),
(87, 1, '2022-09-30 01:25:50', '2022-09-29 22:25:50', '<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2></h2>\n<!-- /wp:heading -->', 'Дом1', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2022-09-30 01:25:50', '2022-09-29 22:25:50', '', 1, 'http://timber-house/?p=87', 0, 'revision', '', 0),
(88, 1, '2022-09-30 01:29:19', '2022-09-29 22:29:19', 'Фото дома класса комфорт', 'project2', 'Фото дома класса комфорт', 'inherit', 'open', 'closed', '', 'project2', '', '', '2022-09-30 01:30:19', '2022-09-29 22:30:19', '', 67, 'http://timber-house/wp-content/uploads/2022/09/project2.jpg', 0, 'attachment', 'image/jpeg', 0),
(89, 1, '2022-09-30 01:30:30', '2022-09-29 22:30:30', 'Схема дома класса комфорт', 'schema2', 'Схема дома класса комфорт', 'inherit', 'open', 'closed', '', 'schema2', '', '', '2022-09-30 01:31:16', '2022-09-29 22:31:16', '', 67, 'http://timber-house/wp-content/uploads/2022/09/schema2.jpg', 0, 'attachment', 'image/jpeg', 0),
(90, 1, '2022-09-30 01:31:25', '2022-09-29 22:31:25', '', 'Дом2', '', 'inherit', 'closed', 'closed', '', '67-revision-v1', '', '', '2022-09-30 01:31:25', '2022-09-29 22:31:25', '', 67, 'http://timber-house/?p=90', 0, 'revision', '', 0),
(91, 1, '2022-09-30 01:39:28', '2022-09-29 22:39:28', '', 'Дом3', '', 'publish', 'open', 'open', '', '%d0%b4%d0%be%d0%bc3', '', '', '2022-09-30 01:39:29', '2022-09-29 22:39:29', '', 0, 'http://timber-house/?p=91', 0, 'post', '', 0),
(92, 1, '2022-09-30 01:38:14', '2022-09-29 22:38:14', '', 'project3', '', 'inherit', 'open', 'closed', '', 'project3', '', '', '2022-09-30 01:38:26', '2022-09-29 22:38:26', '', 91, 'http://timber-house/wp-content/uploads/2022/09/project3.jpg', 0, 'attachment', 'image/jpeg', 0),
(93, 1, '2022-09-30 01:38:38', '2022-09-29 22:38:38', '', 'schema3', '', 'inherit', 'open', 'closed', '', 'schema3', '', '', '2022-09-30 01:38:51', '2022-09-29 22:38:51', '', 91, 'http://timber-house/wp-content/uploads/2022/09/schema3.jpg', 0, 'attachment', 'image/jpeg', 0),
(94, 1, '2022-09-30 01:39:28', '2022-09-29 22:39:28', '', 'Дом3', '', 'inherit', 'closed', 'closed', '', '91-revision-v1', '', '', '2022-09-30 01:39:28', '2022-09-29 22:39:28', '', 91, 'http://timber-house/?p=94', 0, 'revision', '', 0),
(95, 1, '2022-09-30 01:39:29', '2022-09-29 22:39:29', '', 'Дом3', '', 'inherit', 'closed', 'closed', '', '91-revision-v1', '', '', '2022-09-30 01:39:29', '2022-09-29 22:39:29', '', 91, 'http://timber-house/?p=95', 0, 'revision', '', 0),
(96, 1, '2022-09-30 01:41:06', '2022-09-29 22:41:06', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://timber-house/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-09-30 01:41:06', '2022-09-29 22:41:06', '', 2, 'http://timber-house/?p=96', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint UNSIGNED NOT NULL,
  `term_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE `wp_terms` (
  `term_id` bigint UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Без рубрики', '%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8', 0),
(2, 'timber', 'timber', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(9, 2, 0),
(67, 1, 0),
(91, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint UNSIGNED NOT NULL,
  `term_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 3),
(2, 2, 'wp_theme', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'plugin_editor_notice'),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:1:{s:64:\"5ef762894c481e7ad34a807c707648b3d6148d6ffefd37c04ee1dca2acf2b691\";a:4:{s:10:\"expiration\";i:1667073747;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:128:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 OPR/91.0.4516.95\";s:5:\"login\";i:1666900947;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}'),
(19, 1, 'wp_user-settings', 'libraryContent=browse&hidetb=0&editor=tinymce'),
(20, 1, 'wp_user-settings-time', '1664372224'),
(21, 1, 'closedpostboxes_page', 'a:0:{}'),
(22, 1, 'metaboxhidden_page', 'a:0:{}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE `wp_users` (
  `ID` bigint UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$B3YCQZmxoGZoGD1SZgNy2kMOeQJ7ov.', 'admin', 'mark23y_special@ukr.net', 'http://timber-house', '2022-09-26 21:04:38', '', 0, 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`),
  ADD KEY `autoload` (`autoload`);

--
-- Indexes for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=536;

--
-- AUTO_INCREMENT for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=583;

--
-- AUTO_INCREMENT for table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
